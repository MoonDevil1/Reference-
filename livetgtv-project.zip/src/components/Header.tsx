import React from 'react';
import { LiveTgtvLogo } from './Logo';
import { RefreshCw, Play } from 'lucide-react';
import { DeviceMode } from './AndroidSimulator';

export type AppTab = 'guide' | 'stream' | 'project';

interface HeaderProps {
  activeTab: AppTab;
  onTabChange: (tab: AppTab) => void;
  deviceMode: DeviceMode;
  onDeviceModeChange: (mode: DeviceMode) => void;
  onRefreshPlaylist: () => void;
  isRefreshing: boolean;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  onTabChange,
  deviceMode,
  onDeviceModeChange,
  onRefreshPlaylist,
  isRefreshing,
}) => {
  return (
    <header className="flex items-center justify-between gap-8 px-6 py-3.5 bg-[#070b14]/95 backdrop-blur-md border-b border-slate-800/80 sticky top-0 z-40">
      {/* Zone 1: Brand Zone (Single element wordmark) */}
      <a
        href="#"
        onClick={(e) => {
          e.preventDefault();
          onTabChange('guide');
          onDeviceModeChange('responsive');
        }}
        className="whitespace-nowrap shrink-0 group focus:outline-none"
      >
        <LiveTgtvLogo size="md" />
      </a>

      {/* Zone 2: Clean navigation links */}
      <nav className="hidden md:flex items-center gap-6 text-xs font-semibold text-slate-300">
        <button
          onClick={() => {
            onTabChange('guide');
            onDeviceModeChange('responsive');
          }}
          className={`hover:text-cyan-400 transition-colors whitespace-nowrap shrink-0 ${
            activeTab === 'guide' && deviceMode === 'responsive' ? 'text-cyan-400 font-bold' : 'text-slate-300'
          }`}
        >
          Live Guide
        </button>

        <button
          onClick={() => {
            onTabChange('stream');
            onDeviceModeChange('responsive');
          }}
          className={`hover:text-cyan-400 transition-colors whitespace-nowrap shrink-0 flex items-center gap-1.5 ${
            activeTab === 'stream' ? 'text-cyan-400 font-bold' : 'text-slate-300'
          }`}
        >
          <Play className="w-3 h-3 fill-current" />
          Network Stream
        </button>

        <button
          onClick={() => {
            onTabChange('guide');
            onDeviceModeChange(deviceMode === 'phone' ? 'tablet' : 'phone');
          }}
          className={`hover:text-cyan-400 transition-colors whitespace-nowrap shrink-0 ${
            deviceMode !== 'responsive' ? 'text-cyan-400 font-bold' : 'text-slate-300'
          }`}
        >
          Device View ({deviceMode === 'phone' ? 'Phone' : deviceMode === 'tablet' ? 'Tablet' : 'Simulator'})
        </button>

        <button
          onClick={() => onTabChange('project')}
          className={`hover:text-cyan-400 transition-colors whitespace-nowrap shrink-0 ${
            activeTab === 'project' ? 'text-cyan-400 font-bold' : 'text-slate-300'
          }`}
        >
          Android Source & CI
        </button>
      </nav>

      {/* Zone 3: Primary action buttons */}
      <div className="flex items-center gap-2.5 shrink-0">
        <a
          href="/api/download-project.zip"
          download="livetgtv-project.zip"
          className="px-3.5 py-2 text-xs font-semibold text-cyan-300 bg-slate-900 hover:bg-slate-800 border border-cyan-800/60 rounded-lg transition-colors flex items-center gap-1.5 whitespace-nowrap shadow-sm"
          title="Download full Android + Web project ZIP"
        >
          <svg className="w-3.5 h-3.5 text-cyan-400" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
            <path d="M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4"/>
            <polyline points="7 10 12 15 17 10"/>
            <line x1="12" y1="15" x2="12" y2="3"/>
          </svg>
          <span className="hidden sm:inline">Get .ZIP</span>
        </a>

        <button
          onClick={onRefreshPlaylist}
          disabled={isRefreshing}
          className="px-4 py-2 text-xs font-semibold text-slate-950 bg-gradient-to-r from-cyan-400 to-blue-400 hover:opacity-90 rounded-lg transition-opacity flex items-center gap-2 whitespace-nowrap shrink-0 shadow-md shadow-cyan-500/15 disabled:opacity-50"
        >
          <RefreshCw className={`w-3.5 h-3.5 ${isRefreshing ? 'animate-spin' : ''}`} />
          {isRefreshing ? 'Syncing...' : 'Refresh M3U'}
        </button>
      </div>
    </header>
  );
};
