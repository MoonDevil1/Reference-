import { Channel, EPGProgram } from '../types/channel';

interface ScheduleTemplate {
  title: string;
  category: string;
  durationMinutes: number;
  description: string;
  rating: string;
}

const GENRE_PROGRAMS: Record<string, ScheduleTemplate[]> = {
  News: [
    { title: 'Global News Hour & Market Watch', category: 'News', durationMinutes: 60, description: 'Comprehensive breaking coverage of world events, finance, and investigative reports.', rating: 'TV-G' },
    { title: 'Prime Time Debate: World in Focus', category: 'News', durationMinutes: 45, description: 'Expert analysts and policymakers debate current diplomatic and economic developments.', rating: 'TV-PG' },
    { title: 'Frontline Investigative Journal', category: 'News', durationMinutes: 60, description: 'In-depth investigative journalism tracking global stories from the ground.', rating: 'TV-14' },
    { title: 'Headline Fast Track & Weather Radar', category: 'News', durationMinutes: 30, description: 'Rapid updates on regional weather systems, traffic, and international headlines.', rating: 'TV-G' },
  ],
  Sports: [
    { title: 'Live Matchday Live: International Championship', category: 'Sports', durationMinutes: 120, description: 'High-stakes clash featuring live commentary, tactical heatmaps, and pitch-side analysis.', rating: 'TV-G' },
    { title: 'Motorsport Grand Prix Highlights & Paddock Pass', category: 'Sports', durationMinutes: 60, description: 'Behind the scenes at the pit lane with onboard telemetry and driver post-race debriefs.', rating: 'TV-PG' },
    { title: 'World Sports Center: Scores & Highlights', category: 'Sports', durationMinutes: 45, description: 'Nightly recap of goal strikes, slam dunks, and breaking transfer rumors worldwide.', rating: 'TV-G' },
    { title: 'Extreme Sports & Mountain Freeride Series', category: 'Sports', durationMinutes: 60, description: 'Adrenaline-packed downhill mountain biking and big-wave surfing documentary.', rating: 'TV-PG' },
  ],
  Entertainment: [
    { title: 'Golden Hour Drama Series', category: 'Drama', durationMinutes: 60, description: 'Award-winning episodic drama chronicling dynasty intrigue, romance, and rivalry.', rating: 'TV-14' },
    { title: 'Tonight Show with Live Celebrity Guests', category: 'Talk Show', durationMinutes: 60, description: 'Monologues, musical guest performances, and comedy sketches with Hollywood stars.', rating: 'TV-PG' },
    { title: 'The Ultimate Singing Star: Knockout Stage', category: 'Reality', durationMinutes: 90, description: 'Contestants battle it out before celebrity judges in a live nationwide voting showdown.', rating: 'TV-PG' },
    { title: 'Mystery Thriller: Shadows in the Fog', category: 'Mystery', durationMinutes: 60, description: 'Detectives reopen a cold case following an unexpected discovery in a coastal town.', rating: 'TV-14' },
  ],
  Movies: [
    { title: 'Blockbuster Cinema: Cosmic Horizon', category: 'Sci-Fi', durationMinutes: 135, description: 'A crew of astronauts embarks on an uncharted gravitational anomaly to preserve humanity.', rating: 'PG-13' },
    { title: 'Action Classic: Midnight Vendetta', category: 'Action', durationMinutes: 110, description: 'High-octane city car chases and combat as a retired operative protects an innocent witness.', rating: 'R' },
    { title: 'Romantic Rendezvous in Paris', category: 'Romance', durationMinutes: 95, description: 'Two chance encounters ignite a heartwarming romantic journey across historic European streets.', rating: 'PG' },
  ],
  Documentary: [
    { title: 'Deep Ocean Odyssey: The Abyssal Trench', category: 'Nature', durationMinutes: 60, description: 'Submersible deep-sea cameras reveal bioluminescent creatures in untouched oceanic depths.', rating: 'TV-G' },
    { title: 'Cosmic Wonders: The James Webb Discoveries', category: 'Science', durationMinutes: 60, description: 'Astrophysicists decode high-resolution infrared spectrographs from the dawn of time.', rating: 'TV-G' },
    { title: 'Ancient Civilizations: The Lost Citadel', category: 'History', durationMinutes: 60, description: 'LiDAR aerial scanning uncovers sprawling lost urban monuments beneath jungle canopies.', rating: 'TV-PG' },
  ],
  Music: [
    { title: 'Global Hit Chart Countdown Top 50', category: 'Music', durationMinutes: 60, description: 'The hottest charting pop, electronic, and hip-hop music videos of the week.', rating: 'TV-PG' },
    { title: 'Live Acoustic Sessions & Unplugged', category: 'Music', durationMinutes: 60, description: 'Intimate studio live acoustic renditions of fan favorite ballads.', rating: 'TV-G' },
  ],
  Kids: [
    { title: 'Adventures of Spark & Pixel', category: 'Animation', durationMinutes: 30, description: 'A curious young inventor robotic team solves everyday puzzles with science and friendship.', rating: 'TV-Y' },
    { title: 'Wonder Safari: Animal Tales', category: 'Kids', durationMinutes: 30, description: 'Delightful animated wildlife stories teaching kindness, nature, and geography.', rating: 'TV-Y7' },
  ],
};

export function getChannelEPG(channel: Channel): { current: EPGProgram; next: EPGProgram } {
  // Determine genre or fallback
  const group = channel.group || 'Entertainment';
  let matchedKey = Object.keys(GENRE_PROGRAMS).find(k => group.toLowerCase().includes(k.toLowerCase())) || 'Entertainment';
  const list = GENRE_PROGRAMS[matchedKey] || GENRE_PROGRAMS['Entertainment'];

  // Seed with channel number so each channel has unique programs
  const seed = (channel.channelNumber * 7) % list.length;
  const currentTemplate = list[seed];
  const nextTemplate = list[(seed + 1) % list.length];

  const now = new Date();
  const currentMinutes = now.getHours() * 60 + now.getMinutes();
  
  // Calculate slot based on duration
  const duration = currentTemplate.durationMinutes;
  const slotIndex = Math.floor(currentMinutes / duration);
  const startTotalMinutes = slotIndex * duration;
  const endTotalMinutes = startTotalMinutes + duration;

  const elapsed = currentMinutes - startTotalMinutes;
  const progressPercent = Math.min(100, Math.max(0, Math.round((elapsed / duration) * 100)));

  const formatTime = (totalMin: number) => {
    const norm = (totalMin + 1440) % 1440;
    const h = Math.floor(norm / 60);
    const m = norm % 60;
    const period = h >= 12 ? 'PM' : 'AM';
    const displayH = h % 12 || 12;
    return `${displayH}:${m.toString().padStart(2, '0')} ${period}`;
  };

  const nextDuration = nextTemplate.durationMinutes;
  const nextEndTotalMinutes = endTotalMinutes + nextDuration;

  return {
    current: {
      title: `${channel.name}: ${currentTemplate.title}`,
      startTime: formatTime(startTotalMinutes),
      endTime: formatTime(endTotalMinutes),
      progressPercent,
      description: currentTemplate.description,
      category: currentTemplate.category,
      rating: currentTemplate.rating,
    },
    next: {
      title: `${channel.name}: ${nextTemplate.title}`,
      startTime: formatTime(endTotalMinutes),
      endTime: formatTime(nextEndTotalMinutes),
      progressPercent: 0,
      description: nextTemplate.description,
      category: nextTemplate.category,
      rating: nextTemplate.rating,
    },
  };
}
