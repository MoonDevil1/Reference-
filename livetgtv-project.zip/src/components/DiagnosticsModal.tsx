import React from 'react';
import { StreamDiagnosticsData, Channel } from '../types/channel';
import { X, Activity, ShieldCheck, AlertTriangle, Copy, Check, Radio, Cpu, Layers } from 'lucide-react';

interface DiagnosticsModalProps {
  channel: Channel | null;
  diagnostics: StreamDiagnosticsData;
  isOpen: boolean;
  onClose: () => void;
}

export const DiagnosticsModal: React.FC<DiagnosticsModalProps> = ({
  channel,
  diagnostics,
  isOpen,
  onClose,
}) => {
  const [copiedKey, setCopiedKey] = React.useState<string | null>(null);

  if (!isOpen || !channel) return null;

  const copyToClipboard = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(label);
    setTimeout(() => setCopiedKey(null), 2000);
  };

  // Human-readable diagnosis of playback state and errors
  const getDiagnosticAnalysis = () => {
    if (diagnostics.state === 'playing') {
      return {
        status: 'Optimal Playback',
        type: 'success',
        detail: 'ExoPlayer pipeline is actively decoding video frames. Media segments are demuxed and synchronized.',
      };
    }

    if (diagnostics.errorCode === 403 || diagnostics.errorMessage?.includes('403')) {
      return {
        status: 'HTTP 403 Forbidden',
        type: 'error',
        detail: 'The stream CDN token expired, requires IP whitelisting (e.g. Jio India ISP), or rejected the request headers. On Android, Media3 uses OkHttp with custom HMAC cookies; in web browsers, cross-origin security may block direct playback.',
      };
    }

    if (diagnostics.errorCode === 404 || diagnostics.errorMessage?.includes('404')) {
      return {
        status: 'HTTP 404 Manifest Not Found',
        type: 'error',
        detail: 'The manifest file (.m3u8 or .mpd) is no longer available at this endpoint. The broadcaster may have switched master playlist URIs.',
      };
    }

    if (channel.format === 'dash' && channel.drmType === 'clearkey') {
      return {
        status: 'Protected MPEG-DASH (ClearKey DRM)',
        type: 'info',
        detail: 'Stream is encrypted with ClearKey DRM. Media3 ExoPlayer will configure DefaultDrmSessionManagerProvider with the key pairs provided in #KODIPROP.',
      };
    }

    if (diagnostics.state === 'error') {
      return {
        status: 'Playback Error',
        type: 'error',
        detail: diagnostics.errorMessage || 'Unknown decoding or network error occurred during segment fetch.',
      };
    }

    return {
      status: 'Stream Ready / Buffering',
      type: 'info',
      detail: 'Connecting to broadcast gateway and establishing video buffer.',
    };
  };

  const analysis = getDiagnosticAnalysis();

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm animate-in fade-in duration-150">
      <div className="relative w-full max-w-2xl max-h-[90vh] overflow-y-auto bg-slate-900 border border-slate-800 rounded-2xl shadow-2xl text-slate-100 p-6">
        {/* Header */}
        <div className="flex items-center justify-between pb-4 border-b border-slate-800">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-cyan-950/60 border border-cyan-800/40 text-cyan-400">
              <Activity className="w-5 h-5" />
            </div>
            <div>
              <h3 className="text-lg font-bold text-white flex items-center gap-2">
                Stream Diagnostics & Media3 Inspector
              </h3>
              <p className="text-xs text-slate-400">
                Channel #{channel.channelNumber}: {channel.name}
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
            title="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* State Banner */}
        <div className={`mt-4 p-4 rounded-xl border text-sm ${
          analysis.type === 'success'
            ? 'bg-emerald-950/30 border-emerald-800/50 text-emerald-300'
            : analysis.type === 'error'
            ? 'bg-rose-950/30 border-rose-800/50 text-rose-300'
            : 'bg-cyan-950/30 border-cyan-800/50 text-cyan-300'
        }`}>
          <div className="flex items-start gap-2.5">
            {analysis.type === 'error' ? (
              <AlertTriangle className="w-5 h-5 shrink-0 mt-0.5" />
            ) : (
              <ShieldCheck className="w-5 h-5 shrink-0 mt-0.5" />
            )}
            <div>
              <div className="font-semibold text-white">{analysis.status}</div>
              <p className="text-xs opacity-90 mt-1 leading-relaxed">{analysis.detail}</p>
            </div>
          </div>
        </div>

        {/* Key Metrics Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-4 text-xs font-mono">
          <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800/80">
            <span className="text-slate-400 block font-sans text-[11px] mb-1">Manifest Format</span>
            <span className="font-semibold text-cyan-400 uppercase">{channel.format}</span>
          </div>
          <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800/80">
            <span className="text-slate-400 block font-sans text-[11px] mb-1">DRM Scheme</span>
            <span className="font-semibold text-amber-400 uppercase">{channel.drmType || 'None'}</span>
          </div>
          <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800/80">
            <span className="text-slate-400 block font-sans text-[11px] mb-1">State</span>
            <span className="font-semibold text-emerald-400 uppercase">{diagnostics.state}</span>
          </div>
          <div className="p-3 rounded-xl bg-slate-950/60 border border-slate-800/80">
            <span className="text-slate-400 block font-sans text-[11px] mb-1">Group Title</span>
            <span className="font-semibold text-slate-200 truncate block">{channel.group}</span>
          </div>
        </div>

        {/* Technical Attributes */}
        <div className="mt-4 space-y-3">
          {/* Stream URL */}
          <div className="p-3 rounded-xl bg-slate-950/80 border border-slate-800">
            <div className="flex items-center justify-between text-xs text-slate-400 mb-1">
              <span className="font-semibold text-slate-300">Stream URL (Target Manifest)</span>
              <button
                onClick={() => copyToClipboard(channel.streamUrl, 'url')}
                className="flex items-center gap-1 text-[11px] text-cyan-400 hover:text-cyan-300"
              >
                {copiedKey === 'url' ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                Copy URL
              </button>
            </div>
            <p className="text-xs font-mono text-slate-300 break-all bg-slate-900/90 p-2 rounded border border-slate-800">
              {channel.streamUrl}
            </p>
          </div>

          {/* DRM License Key */}
          {channel.licenseKey && (
            <div className="p-3 rounded-xl bg-slate-950/80 border border-slate-800">
              <div className="flex items-center justify-between text-xs text-slate-400 mb-1">
                <span className="font-semibold text-amber-300 flex items-center gap-1.5">
                  <ShieldCheck className="w-3.5 h-3.5" /> ClearKey DRM Pairs (#KODIPROP)
                </span>
                <button
                  onClick={() => copyToClipboard(channel.licenseKey || '', 'drm')}
                  className="flex items-center gap-1 text-[11px] text-cyan-400 hover:text-cyan-300"
                >
                  {copiedKey === 'drm' ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                  Copy Key
                </button>
              </div>
              <p className="text-xs font-mono text-amber-200 break-all bg-slate-900/90 p-2 rounded border border-slate-800">
                {channel.licenseKey}
              </p>
            </div>
          )}

          {/* HTTP Headers */}
          {(channel.userAgent || channel.cookie || channel.referer || channel.extraHeaders) && (
            <div className="p-3 rounded-xl bg-slate-950/80 border border-slate-800">
              <span className="font-semibold text-xs text-slate-300 block mb-2">
                HTTP Headers & Credentials (#EXTVLCOPT / #EXTHTTP)
              </span>
              <div className="space-y-1.5 text-xs font-mono">
                {channel.userAgent && (
                  <div className="bg-slate-900/90 p-2 rounded border border-slate-800">
                    <span className="text-slate-400 block text-[10px] uppercase">User-Agent:</span>
                    <span className="text-slate-200 break-all">{channel.userAgent}</span>
                  </div>
                )}
                {channel.cookie && (
                  <div className="bg-slate-900/90 p-2 rounded border border-slate-800">
                    <span className="text-slate-400 block text-[10px] uppercase">Cookie (Auth Token):</span>
                    <span className="text-slate-200 break-all">{channel.cookie}</span>
                  </div>
                )}
                {channel.referer && (
                  <div className="bg-slate-900/90 p-2 rounded border border-slate-800">
                    <span className="text-slate-400 block text-[10px] uppercase">Referer:</span>
                    <span className="text-slate-200 break-all">{channel.referer}</span>
                  </div>
                )}
              </div>
            </div>
          )}
        </div>

        {/* Android Media3 Note */}
        <div className="mt-5 p-3 rounded-xl bg-blue-950/20 border border-blue-900/40 text-xs text-slate-300 flex items-start gap-2.5">
          <Layers className="w-4 h-4 text-blue-400 shrink-0 mt-0.5" />
          <p className="leading-relaxed">
            <strong className="text-blue-300">Native Android ExoPlayer Implementation:</strong> In the generated Android project, <code className="text-cyan-300">ExoPlayerManager.kt</code> injects these exact headers into <code className="text-cyan-300">OkHttpDataSource.Factory</code> and applies ClearKey DRM to <code className="text-cyan-300">MediaItem.DrmConfiguration</code>.
          </p>
        </div>

        {/* Footer */}
        <div className="mt-6 flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold text-white bg-slate-800 hover:bg-slate-700 rounded-lg transition-colors"
          >
            Close Diagnostics
          </button>
        </div>
      </div>
    </div>
  );
};
