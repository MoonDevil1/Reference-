import React, { useState, useEffect } from 'react';
import { Channel, StreamFormat, DrmType } from '../types/channel';
import {
  Play, Radio, History, ShieldCheck, Settings, Trash2,
  ExternalLink, Sparkles, Plus, Clock, Copy, Check, ChevronDown, ChevronUp
} from 'lucide-react';

export interface StreamHistoryItem {
  id: string;
  name: string;
  url: string;
  format: StreamFormat;
  drmType: DrmType;
  licenseKey?: string;
  licenseUrl?: string;
  userAgent?: string;
  cookie?: string;
  referer?: string;
  playedAt: number;
}

interface NetworkStreamHubProps {
  onPlayStream: (channel: Channel) => void;
  currentChannel: Channel | null;
}

const PRESET_STREAMS: Omit<StreamHistoryItem, 'id' | 'playedAt'>[] = [
  {
    name: 'LiveTGTV Sports Live (HLS Adaptive)',
    url: 'https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8',
    format: 'hls',
    drmType: 'none',
  },
  {
    name: 'LiveTGTV Action 4K (Akamai Live)',
    url: 'https://cph-p2p-msl.akamaized.net/hls/live/2000341/test/master.m3u8',
    format: 'hls',
    drmType: 'none',
  },
  {
    name: 'DW News English 24/7 (Live HLS)',
    url: 'https://dwamdstream102.akamaized.net/hls/live/2015525/dwstream102/index.m3u8',
    format: 'hls',
    drmType: 'none',
  },
  {
    name: 'Red Bull TV Sports & Adventure (HLS)',
    url: 'https://rbmn-live.akamaized.net/hls/live/590964/BoRB-AT/master.m3u8',
    format: 'hls',
    drmType: 'none',
  },
  {
    name: 'LiveTGTV Cinema (MPEG-DASH)',
    url: 'https://dash.akamaized.net/akamai/bbb_30fps/bbb_30fps.mpd',
    format: 'dash',
    drmType: 'none',
  },
  {
    name: 'NASA TV Live (HLS Master)',
    url: 'https://ntv1.akamaized.net/hls/live/2014075/NASA-NTV1-HLS/master.m3u8',
    format: 'hls',
    drmType: 'none',
  },
  {
    name: 'LiveTGTV Oceans 1080p (Direct MP4)',
    url: 'https://vjs.zencdn.net/v/oceans.mp4',
    format: 'mp4',
    drmType: 'none',
  },
  {
    name: 'LiveTGTV Animation 4K (Direct MP4)',
    url: 'https://media.w3.org/2010/05/sintel/trailer.mp4',
    format: 'mp4',
    drmType: 'none',
  },
];

export const NetworkStreamHub: React.FC<NetworkStreamHubProps> = ({
  onPlayStream,
  currentChannel,
}) => {
  const [streamUrl, setStreamUrl] = useState('');
  const [streamName, setStreamName] = useState('');
  const [format, setFormat] = useState<StreamFormat>('unknown');
  const [showAdvanced, setShowAdvanced] = useState(false);

  // Advanced HTTP headers
  const [userAgent, setUserAgent] = useState('');
  const [referer, setReferer] = useState('');
  const [cookie, setCookie] = useState('');

  // DRM Settings
  const [drmType, setDrmType] = useState<DrmType>('none');
  const [licenseKey, setLicenseKey] = useState('');
  const [licenseUrl, setLicenseUrl] = useState('');

  // History State
  const [history, setHistory] = useState<StreamHistoryItem[]>(() => {
    try {
      const saved = localStorage.getItem('livetgtv_stream_history');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [copiedId, setCopiedId] = useState<string | null>(null);

  // Auto-detect format from URL
  useEffect(() => {
    const url = streamUrl.trim().toLowerCase();
    if (url.includes('.m3u8') || url.includes('/hls/')) {
      setFormat('hls');
    } else if (url.includes('.mpd') || url.includes('/dash/') || url.includes('/wdvlive/')) {
      setFormat('dash');
    } else if (url.includes('.mp4')) {
      setFormat('mp4');
    } else if (url.startsWith('rtmp://') || url.startsWith('rtsp://')) {
      setFormat('unknown');
    }
  }, [streamUrl]);

  const saveToHistory = (item: Omit<StreamHistoryItem, 'id' | 'playedAt'>) => {
    const newItem: StreamHistoryItem = {
      ...item,
      id: `stream_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      playedAt: Date.now(),
    };

    setHistory((prev) => {
      // Remove duplicate if same URL
      const filtered = prev.filter((i) => i.url !== newItem.url);
      const updated = [newItem, ...filtered].slice(0, 20); // Keep last 20
      try {
        localStorage.setItem('livetgtv_stream_history', JSON.stringify(updated));
      } catch {}
      return updated;
    });
  };

  const clearHistory = () => {
    setHistory([]);
    try {
      localStorage.removeItem('livetgtv_stream_history');
    } catch {}
  };

  const removeHistoryItem = (id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setHistory((prev) => {
      const updated = prev.filter((item) => item.id !== id);
      try {
        localStorage.setItem('livetgtv_stream_history', JSON.stringify(updated));
      } catch {}
      return updated;
    });
  };

  const handleStartPlayback = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    const url = streamUrl.trim();
    if (!url) return;

    const detectedFormat: StreamFormat = format !== 'unknown'
      ? format
      : url.includes('.m3u8')
      ? 'hls'
      : url.includes('.mpd')
      ? 'dash'
      : url.includes('.mp4')
      ? 'mp4'
      : 'hls';

    const cleanName = streamName.trim() || `Network Stream (${detectedFormat.toUpperCase()})`;

    const streamData = {
      name: cleanName,
      url,
      format: detectedFormat,
      drmType,
      licenseKey: licenseKey.trim() || undefined,
      licenseUrl: licenseUrl.trim() || undefined,
      userAgent: userAgent.trim() || undefined,
      cookie: cookie.trim() || undefined,
      referer: referer.trim() || undefined,
    };

    saveToHistory(streamData);

    const channelObj: Channel = {
      id: `custom_${Date.now()}`,
      name: cleanName,
      group: 'Network Streams',
      streamUrl: url,
      format: detectedFormat,
      drmType,
      licenseKey: licenseKey.trim() || undefined,
      licenseUrl: licenseUrl.trim() || undefined,
      userAgent: userAgent.trim() || undefined,
      cookie: cookie.trim() || undefined,
      referer: referer.trim() || undefined,
      channelNumber: 999,
    };

    onPlayStream(channelObj);
  };

  const playFromHistory = (item: StreamHistoryItem) => {
    setStreamUrl(item.url);
    setStreamName(item.name);
    setFormat(item.format);
    setDrmType(item.drmType);
    if (item.licenseKey) setLicenseKey(item.licenseKey);
    if (item.licenseUrl) setLicenseUrl(item.licenseUrl);
    if (item.userAgent) setUserAgent(item.userAgent);
    if (item.cookie) setCookie(item.cookie);
    if (item.referer) setReferer(item.referer);

    const channelObj: Channel = {
      id: item.id,
      name: item.name,
      group: 'Network Streams',
      streamUrl: item.url,
      format: item.format,
      drmType: item.drmType,
      licenseKey: item.licenseKey,
      licenseUrl: item.licenseUrl,
      userAgent: item.userAgent,
      cookie: item.cookie,
      referer: item.referer,
      channelNumber: 999,
    };

    onPlayStream(channelObj);
  };

  const copyUrl = (text: string, id: string, e: React.MouseEvent) => {
    e.stopPropagation();
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  return (
    <div className="w-full max-w-6xl mx-auto p-4 sm:p-6 space-y-6">
      {/* Top Banner (com.genuine.leone style) */}
      <div className="p-6 rounded-2xl bg-gradient-to-r from-slate-900 via-slate-900 to-blue-950/40 border border-slate-800 shadow-xl flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-cyan-400 font-mono text-xs font-semibold uppercase tracking-wider mb-1">
            <Radio className="w-4 h-4" /> Universal Network Stream Player
          </div>
          <h2 className="text-xl sm:text-2xl font-bold text-white tracking-tight">
            Play Custom Network Video Streams
          </h2>
          <p className="text-xs sm:text-sm text-slate-300 mt-1 max-w-2xl leading-relaxed">
            Directly stream HLS (.m3u8), MPEG-DASH (.mpd), MP4, and WebM protocols with custom User-Agent, Cookie, Referer headers, and ClearKey / Widevine DRM decryption.
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Stream URL Input Card (7 cols) */}
        <div className="lg:col-span-7 bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800/80 pb-3">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <Play className="w-4 h-4 text-cyan-400 fill-current" />
              Stream URL & Headers
            </h3>
            <span className="text-[11px] font-mono text-slate-400">
              Protocol: <span className="text-cyan-400 font-semibold uppercase">{format}</span>
            </span>
          </div>

          <form onSubmit={handleStartPlayback} className="space-y-4">
            {/* Stream URL */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Media Stream URL (Required)
              </label>
              <div className="relative">
                <input
                  type="url"
                  required
                  placeholder="https://example.com/live/stream.m3u8"
                  value={streamUrl}
                  onChange={(e) => setStreamUrl(e.target.value)}
                  className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-xs font-mono text-cyan-300 placeholder-slate-500 focus:outline-none focus:border-cyan-500 transition-colors"
                />
              </div>
            </div>

            {/* Stream Label / Title */}
            <div>
              <label className="block text-xs font-semibold text-slate-300 mb-1">
                Stream Label (Optional)
              </label>
              <input
                type="text"
                placeholder="e.g. My Sports Feed, News Broadcast"
                value={streamName}
                onChange={(e) => setStreamName(e.target.value)}
                className="w-full px-3.5 py-2 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500 transition-colors"
              />
            </div>

            {/* Format Manual Override */}
            <div className="flex items-center gap-2 text-xs">
              <span className="text-slate-400 font-medium">Format:</span>
              {(['unknown', 'hls', 'dash', 'mp4'] as const).map((fmt) => (
                <button
                  type="button"
                  key={fmt}
                  onClick={() => setFormat(fmt)}
                  className={`px-2.5 py-1 rounded-lg uppercase font-mono text-[11px] transition-colors ${
                    format === fmt
                      ? 'bg-cyan-500 text-slate-950 font-bold'
                      : 'bg-slate-950 text-slate-400 hover:text-white border border-slate-800'
                  }`}
                >
                  {fmt}
                </button>
              ))}
            </div>

            {/* Collapsible Advanced Headers & DRM */}
            <div className="border border-slate-800/80 rounded-xl overflow-hidden bg-slate-950/40">
              <button
                type="button"
                onClick={() => setShowAdvanced(!showAdvanced)}
                className="w-full px-4 py-2.5 flex items-center justify-between text-xs font-semibold text-slate-300 hover:text-white hover:bg-slate-800/50 transition-colors"
              >
                <div className="flex items-center gap-2">
                  <Settings className="w-3.5 h-3.5 text-cyan-400" />
                  <span>Custom HTTP Headers & DRM Decryption</span>
                </div>
                {showAdvanced ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
              </button>

              {showAdvanced && (
                <div className="p-4 space-y-3.5 border-t border-slate-800/80 text-xs">
                  {/* User-Agent */}
                  <div>
                    <label className="block text-[11px] font-semibold text-slate-400 mb-1">
                      User-Agent (HTTP Header)
                    </label>
                    <input
                      type="text"
                      placeholder="e.g. PlayTV/7.1.5 (Linux;Android 8.1.0) ExoPlayerLib/2.11.7"
                      value={userAgent}
                      onChange={(e) => setUserAgent(e.target.value)}
                      className="w-full px-3 py-1.5 rounded-lg bg-slate-950 border border-slate-800 text-slate-200 font-mono text-[11px] focus:outline-none focus:border-cyan-500"
                    />
                  </div>

                  {/* Cookie Header */}
                  <div>
                    <label className="block text-[11px] font-semibold text-slate-400 mb-1">
                      Cookie / Token Header
                    </label>
                    <input
                      type="text"
                      placeholder="e.g. __hdnea__=st=1794318172~exp=1794339772~acl=/*~hmac=..."
                      value={cookie}
                      onChange={(e) => setCookie(e.target.value)}
                      className="w-full px-3 py-1.5 rounded-lg bg-slate-950 border border-slate-800 text-slate-200 font-mono text-[11px] focus:outline-none focus:border-cyan-500"
                    />
                  </div>

                  {/* Referer Header */}
                  <div>
                    <label className="block text-[11px] font-semibold text-slate-400 mb-1">
                      Referer Header
                    </label>
                    <input
                      type="text"
                      placeholder="https://broadcast-origin.com/"
                      value={referer}
                      onChange={(e) => setReferer(e.target.value)}
                      className="w-full px-3 py-1.5 rounded-lg bg-slate-950 border border-slate-800 text-slate-200 font-mono text-[11px] focus:outline-none focus:border-cyan-500"
                    />
                  </div>

                  {/* DRM Configuration */}
                  <div className="pt-2 border-t border-slate-800/80">
                    <span className="block text-[11px] font-semibold text-amber-300 mb-2 flex items-center gap-1.5">
                      <ShieldCheck className="w-3.5 h-3.5" /> DRM Protection Scheme
                    </span>
                    <div className="flex items-center gap-2 mb-3">
                      {(['none', 'clearkey', 'widevine'] as const).map((scheme) => (
                        <button
                          type="button"
                          key={scheme}
                          onClick={() => setDrmType(scheme)}
                          className={`px-2.5 py-1 rounded text-[11px] font-medium capitalize transition-colors ${
                            drmType === scheme
                              ? 'bg-amber-500 text-slate-950 font-bold'
                              : 'bg-slate-900 text-slate-400 border border-slate-800 hover:text-white'
                          }`}
                        >
                          {scheme}
                        </button>
                      ))}
                    </div>

                    {drmType === 'clearkey' && (
                      <div>
                        <label className="block text-[11px] text-slate-400 mb-1">
                          ClearKey Key ID : Key (hex pair or comma-separated pairs)
                        </label>
                        <input
                          type="text"
                          placeholder="e.g. c6255706bca250079aeaf1fc4474d1b9:eab6217aac6f1feec103120e6218eb43"
                          value={licenseKey}
                          onChange={(e) => setLicenseKey(e.target.value)}
                          className="w-full px-3 py-1.5 rounded-lg bg-slate-950 border border-slate-800 text-amber-300 font-mono text-[11px] focus:outline-none focus:border-amber-500"
                        />
                      </div>
                    )}

                    {drmType === 'widevine' && (
                      <div>
                        <label className="block text-[11px] text-slate-400 mb-1">
                          Widevine License Server URL
                        </label>
                        <input
                          type="url"
                          placeholder="https://widevine-proxy.example.com/acquire-license"
                          value={licenseUrl}
                          onChange={(e) => setLicenseUrl(e.target.value)}
                          className="w-full px-3 py-1.5 rounded-lg bg-slate-950 border border-slate-800 text-amber-300 font-mono text-[11px] focus:outline-none focus:border-amber-500"
                        />
                      </div>
                    )}
                  </div>
                </div>
              )}
            </div>

            {/* Play Button */}
            <button
              type="submit"
              disabled={!streamUrl.trim()}
              className="w-full py-3 rounded-xl bg-gradient-to-r from-cyan-400 to-blue-500 hover:opacity-90 text-slate-950 font-bold text-sm flex items-center justify-center gap-2 shadow-lg shadow-cyan-500/20 transition-all disabled:opacity-50"
            >
              <Play className="w-4 h-4 fill-current" />
              Start Network Stream Playback
            </button>
          </form>

          {/* Quick Presets Bar */}
          <div className="pt-4 border-t border-slate-800/80">
            <span className="text-[11px] font-semibold text-slate-400 uppercase tracking-wider block mb-2">
              Quick Test Presets
            </span>
            <div className="flex flex-wrap gap-1.5">
              {PRESET_STREAMS.map((preset) => (
                <button
                  key={preset.name}
                  onClick={() => {
                    setStreamUrl(preset.url);
                    setStreamName(preset.name);
                    setFormat(preset.format);
                    setDrmType(preset.drmType);
                  }}
                  className="px-2.5 py-1 rounded-lg bg-slate-950 hover:bg-slate-800 text-[11px] text-slate-300 hover:text-white border border-slate-800 transition-colors flex items-center gap-1.5"
                >
                  <Sparkles className="w-3 h-3 text-cyan-400" />
                  {preset.name}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Stream History & Bookmarks (5 cols) */}
        <div className="lg:col-span-5 bg-slate-900/90 border border-slate-800 rounded-2xl p-5 shadow-xl space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800/80 pb-3">
            <div className="flex items-center gap-2">
              <History className="w-4 h-4 text-cyan-400" />
              <h3 className="text-sm font-bold text-white">Stream Playback History</h3>
            </div>
            {history.length > 0 && (
              <button
                onClick={clearHistory}
                className="text-[11px] text-slate-400 hover:text-rose-400 flex items-center gap-1 transition-colors"
              >
                <Trash2 className="w-3 h-3" /> Clear
              </button>
            )}
          </div>

          {history.length === 0 ? (
            <div className="py-12 text-center text-slate-500 space-y-2">
              <Clock className="w-8 h-8 mx-auto opacity-40" />
              <p className="text-xs">No stream history yet</p>
              <p className="text-[11px] text-slate-600">
                Played network streams and URLs will appear here for one-tap relaunch.
              </p>
            </div>
          ) : (
            <div className="space-y-2 max-h-[460px] overflow-y-auto pr-1">
              {history.map((item) => (
                <div
                  key={item.id}
                  onClick={() => playFromHistory(item)}
                  className="p-3 rounded-xl bg-slate-950/80 hover:bg-slate-800/80 border border-slate-800/80 hover:border-slate-700 transition-all cursor-pointer group flex items-start justify-between gap-3"
                >
                  <div className="min-w-0 flex-1">
                    <div className="flex items-center gap-2">
                      <span className="text-[9px] font-mono font-bold uppercase px-1.5 py-0.5 rounded bg-cyan-950/80 text-cyan-400 border border-cyan-800/40">
                        {item.format}
                      </span>
                      {item.drmType !== 'none' && (
                        <span className="text-[9px] font-mono uppercase px-1.5 py-0.5 rounded bg-amber-950/80 text-amber-400 border border-amber-800/40">
                          {item.drmType}
                        </span>
                      )}
                      <h4 className="text-xs font-semibold text-white truncate group-hover:text-cyan-300">
                        {item.name}
                      </h4>
                    </div>
                    <p className="text-[11px] font-mono text-slate-400 truncate mt-1">
                      {item.url}
                    </p>
                  </div>

                  <div className="flex items-center gap-1 shrink-0 pt-0.5">
                    <button
                      onClick={(e) => copyUrl(item.url, item.id, e)}
                      className="p-1 text-slate-500 hover:text-slate-300 rounded"
                      title="Copy URL"
                    >
                      {copiedId === item.id ? (
                        <Check className="w-3.5 h-3.5 text-emerald-400" />
                      ) : (
                        <Copy className="w-3.5 h-3.5" />
                      )}
                    </button>
                    <button
                      onClick={(e) => removeHistoryItem(item.id, e)}
                      className="p-1 text-slate-500 hover:text-rose-400 rounded"
                      title="Remove from history"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
