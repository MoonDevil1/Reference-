import { Channel, ChannelEPGData, EPGProgram } from '../types/channel';

export const DEFAULT_XMLTV_URL = 'https://avkb.short.gy/jioepg.xml.gz';

/**
 * Procedural show title templates based on genre/group
 */
const GENRE_SCHEDULES: Record<string, { titles: string[]; categories: string[]; descriptions: string[] }> = {
  sports: {
    titles: [
      'Live: International Cricket Trophy Live',
      'Matchday Studio & Expert Analysis',
      'Premier League: Weekend Super Clash',
      'Grand Slam Tennis Highlights & Vault',
      'Motorsport Grand Prix: Qualifying Rounds',
      'Fight Night Live: Championship Round',
      'Sports Extra: Daily News & Scorecard',
    ],
    categories: ['Sports', 'Live Sports', 'Football', 'Cricket', 'Motorsport'],
    descriptions: [
      'Comprehensive live broadcast coverage with multi-cam replays and post-match studio expert debate.',
      'In-depth statistical breakdown, player interviews, and upcoming tactical strategy discussions.',
      'High-stakes live league action featuring the season’s leading contenders in an intense battle.',
      'All the unforgettable rallies, clutch set-points, and courtside commentary from today’s action.',
      'High-speed track action with telemetry diagnostics, pit-lane updates, and lap time telemetry.',
    ],
  },
  movies: {
    titles: [
      'World Television Premiere: The Vanguard',
      'Blockbuster Movie Night: The Reckoning',
      'Golden Cinema Classic: Romance in the Rain',
      'Action Hour: Velocity Zero',
      'Mystery Thriller: The Midnight Suspect',
      'Family Comedy Fiesta: Double Trouble',
    ],
    categories: ['Feature Film', 'Action', 'Drama', 'Thriller', 'Comedy'],
    descriptions: [
      'A thrilling cinematic spectacle following an elite squad confronted with their greatest challenge.',
      'An action-packed blockbuster featuring high-octane stunts, dramatic twists, and unforgettable performances.',
      'A timeless classic that captivated audiences across generations with its heartfelt musical score.',
      'Adrenaline-fueled thriller with non-stop car chases, tactical battles, and breathtaking cinematography.',
      'An enigmatic detective races against the clock to solve a high-profile disappearance before dawn.',
    ],
  },
  news: {
    titles: [
      'Prime Time 360: The Big Debate',
      'Global Headlines & Breaking Bulletin',
      'Morning Briefing: Top Stories of the Day',
      'Special Investigation: The Unseen Truth',
      'Business & Financial Markets Today',
      'World News Watch: Diplomatic Dispatch',
    ],
    categories: ['News', 'Current Affairs', 'Debate', 'Finance', 'Documentary'],
    descriptions: [
      'The biggest debate of the day with key political commentators, economists, and field correspondents.',
      'Fast-paced round-up of breaking news events, national updates, and live ground reporting.',
      'Essential morning headlines, weather forecasts, stock exchange openings, and traffic advisories.',
      'An investigative deep-dive examining policy impacts, social shifts, and consumer insights.',
      'Live market wrap featuring Wall Street and global indices, currency rates, and market forecasts.',
    ],
  },
  entertainment: {
    titles: [
      'Prime Time Drama: Bonds of Destiny',
      'The Grand Reality Talent Show',
      'Evening Serials: Whispers of the Heart',
      'Celebrity Lounge & Behind the Scenes',
      'Late Night Comedy & Stand-up Spotlight',
      'Mega Game Show: Fortune Wheel Live',
    ],
    categories: ['Series', 'Reality Show', 'Drama', 'Comedy', 'Entertainment'],
    descriptions: [
      'Dramatic twists unfold as long-buried family secrets threaten to dismantle life-long alliances.',
      'Contestants from across the nation perform live before a panel of celebrity judges to win the grand title.',
      'An emotional tale of resilience, passion, and personal redemption amidst modern societal pressures.',
      'Exclusive backstage interviews, uncensored bloopers, and intimate conversations with your favorite stars.',
      'Hilarious stand-up sketches, satirical parodies, and lively musical guests to end your evening with a smile.',
    ],
  },
  kids: {
    titles: [
      'Adventures of the Space Explorers',
      'The Magic School & Whimsical Pets',
      'Super Toons: Defenders of the City',
      'Fun Science Laboratory & Crafts',
      'Bedtime Fairy Tales & Animated Legends',
    ],
    categories: ['Animation', 'Kids', 'Educational', 'Cartoon'],
    descriptions: [
      'Join an adventurous trio as they travel through alien galaxies solving puzzles and making cosmic friends.',
      'Delightful animated fun where enchanted animals learn life lessons, friendship, and teamwork.',
      'Young heroes use their wacky superpowers to outsmart mischievous villains and keep the city safe.',
      'Interactive science experiments and creative craft ideas made simple and fun for curious young minds.',
    ],
  },
  music: {
    titles: [
      'Top 50 Non-Stop Chartbusters',
      'Retro Melodies: Golden 90s Hits',
      'Acoustic Unplugged Live Sessions',
      'Club Anthem Hour: EDM & Remixes',
      'Soulful Rhythms & Classical Fusion',
    ],
    categories: ['Music', 'Concert', 'Pop', 'Dance'],
    descriptions: [
      'The hottest singles, trending viral songs, and countdown favorites back-to-back without interruption.',
      'Nostalgic golden era classics that defined a generation, restored in pristine digital audio.',
      'Intimate acoustic sets and raw studio performances by celebrated independent recording artists.',
      'High-energy dance remixes and club floor-fillers mixed seamlessly by premier international DJs.',
    ],
  },
};

/**
 * Formats milliseconds timestamp to HH:mm string
 */
export function formatTimestampToHHMM(timestamp: number): string {
  const date = new Date(timestamp);
  const hours = date.getHours().toString().padStart(2, '0');
  const minutes = date.getMinutes().toString().padStart(2, '0');
  return `${hours}:${minutes}`;
}

/**
 * Calculates current progress percentage and time remaining
 */
export function calculateProgramProgress(
  startTimestamp?: number,
  endTimestamp?: number
): { progressPercent: number; remainingMinutes: number; elapsedMinutes: number } {
  if (!startTimestamp || !endTimestamp || endTimestamp <= startTimestamp) {
    return { progressPercent: 0, remainingMinutes: 0, elapsedMinutes: 0 };
  }

  const now = Date.now();
  const totalDuration = endTimestamp - startTimestamp;
  const elapsed = Math.max(0, now - startTimestamp);
  const remaining = Math.max(0, endTimestamp - now);

  const progressPercent = Math.min(100, Math.max(0, Math.round((elapsed / totalDuration) * 100)));
  const remainingMinutes = Math.max(0, Math.round(remaining / 60000));
  const elapsedMinutes = Math.max(0, Math.round(elapsed / 60000));

  return { progressPercent, remainingMinutes, elapsedMinutes };
}

/**
 * Generates an aesthetic, realistic procedural fallback schedule
 * for channels that don't have XMLTV records.
 */
export function generateFallbackEPG(channel: Channel, sourceUrl = DEFAULT_XMLTV_URL): ChannelEPGData {
  const now = Date.now();
  const groupKey = (channel.group || '').toLowerCase();

  let matchedGenre = 'entertainment';
  if (groupKey.includes('sport') || channel.name.toLowerCase().includes('sport')) {
    matchedGenre = 'sports';
  } else if (groupKey.includes('movie') || groupKey.includes('cinema') || channel.name.toLowerCase().includes('cinema')) {
    matchedGenre = 'movies';
  } else if (groupKey.includes('news') || channel.name.toLowerCase().includes('news')) {
    matchedGenre = 'news';
  } else if (groupKey.includes('music') || channel.name.toLowerCase().includes('music') || channel.name.toLowerCase().includes('vh1')) {
    matchedGenre = 'music';
  } else if (groupKey.includes('kid') || groupKey.includes('cartoon') || groupKey.includes('anim')) {
    matchedGenre = 'kids';
  }

  const scheduleConfig = GENRE_SCHEDULES[matchedGenre] || GENRE_SCHEDULES.entertainment;

  // Use channel number to seed distinct title sequence
  const seed = (channel.channelNumber || 1) % scheduleConfig.titles.length;

  // Standard show slot: 30 to 60 mins. Align to neat 30-min block
  const currentSlotDurationMs = 45 * 60 * 1000; // 45 mins
  const slotModulo = now % currentSlotDurationMs;
  const currentStartMs = now - slotModulo;
  const currentEndMs = currentStartMs + currentSlotDurationMs;

  const currentTitle = scheduleConfig.titles[seed % scheduleConfig.titles.length];
  const currentCategory = scheduleConfig.categories[seed % scheduleConfig.categories.length];
  const currentDesc = scheduleConfig.descriptions[seed % scheduleConfig.descriptions.length];

  const currentProgram: EPGProgram = {
    title: currentTitle,
    category: currentCategory,
    description: `${currentDesc} Broadcasting live on ${channel.name}.`,
    startTime: formatTimestampToHHMM(currentStartMs),
    endTime: formatTimestampToHHMM(currentEndMs),
    startTimestamp: currentStartMs,
    endTimestamp: currentEndMs,
    progressPercent: Math.min(100, Math.max(0, Math.round((slotModulo / currentSlotDurationMs) * 100))),
    channelId: channel.tvgId || channel.id,
    rating: 'PG-13',
  };

  const upcomingPrograms: EPGProgram[] = [];
  let nextStart = currentEndMs;

  for (let i = 1; i <= 8; i++) {
    const showIdx = (seed + i) % scheduleConfig.titles.length;
    const catIdx = (seed + i) % scheduleConfig.categories.length;
    const descIdx = (seed + i) % scheduleConfig.descriptions.length;
    const durationMins = (i % 2 === 0) ? 60 : 30;
    const durationMs = durationMins * 60 * 1000;
    const nextEnd = nextStart + durationMs;

    upcomingPrograms.push({
      title: scheduleConfig.titles[showIdx],
      category: scheduleConfig.categories[catIdx],
      description: `${scheduleConfig.descriptions[descIdx]} Scheduled broadcast on ${channel.name}.`,
      startTime: formatTimestampToHHMM(nextStart),
      endTime: formatTimestampToHHMM(nextEnd),
      startTimestamp: nextStart,
      endTimestamp: nextEnd,
      progressPercent: 0,
      channelId: channel.tvgId || channel.id,
      rating: i % 3 === 0 ? 'TV-14' : 'U/A',
    });

    nextStart = nextEnd;
  }

  return {
    channelId: channel.tvgId || channel.id,
    channelName: channel.name,
    sourceUrl,
    updatedAt: now,
    current: currentProgram,
    upcoming: upcomingPrograms,
    hasLiveMetadata: false, // fallback generated
  };
}

/**
 * Fetches real EPG data for a channel from the Express proxy server
 * with seamless fallback when data is unavailable.
 */
export async function fetchChannelEPG(
  channel: Channel,
  options?: {
    epgUrl?: string;
    forceRefresh?: boolean;
  }
): Promise<ChannelEPGData> {
  const targetEpgUrl = options?.epgUrl || DEFAULT_XMLTV_URL;
  const channelQuery = channel.tvgId || channel.id;
  const channelNameQuery = channel.name;

  try {
    const params = new URLSearchParams({
      channelId: channelQuery,
      channelName: channelNameQuery,
      url: targetEpgUrl,
      ...(options?.forceRefresh ? { refresh: 'true' } : {}),
    });

    const response = await fetch(`/api/epg?${params.toString()}`);
    if (!response.ok) {
      throw new Error(`EPG endpoint returned HTTP ${response.status}`);
    }

    const data: ChannelEPGData = await response.json();

    // If server returned real EPG data with a current show
    if (data.hasLiveMetadata && data.current) {
      // Re-calculate real-time progress on client
      if (data.current.startTimestamp && data.current.endTimestamp) {
        const { progressPercent } = calculateProgramProgress(
          data.current.startTimestamp,
          data.current.endTimestamp
        );
        data.current.progressPercent = progressPercent;
      }
      return data;
    }

    // Fallback schedule if the channel is not present in XMLTV
    return generateFallbackEPG(channel, targetEpgUrl);
  } catch (error) {
    console.warn(`[EPG Service] Falling back to procedural schedule for ${channel.name}:`, error);
    return generateFallbackEPG(channel, targetEpgUrl);
  }
}
