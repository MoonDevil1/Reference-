package com.livetgtv.app.data.model

data class Channel(
    val id: String,
    val name: String,
    val tvgId: String? = null,
    val tvgName: String? = null,
    val group: String = "General",
    val logoUrl: String? = null,
    val streamUrl: String,
    val format: StreamFormat = StreamFormat.UNKNOWN,
    val drmType: DrmType = DrmType.NONE,
    val licenseKey: String? = null,
    val licenseUrl: String? = null,
    val userAgent: String? = null,
    val cookie: String? = null,
    val referer: String? = null,
    val extraHeaders: Map<String, String> = emptyMap(),
    val channelNumber: Int = 1
)

enum class StreamFormat {
    HLS,
    DASH,
    MP4,
    UNKNOWN
}

enum class DrmType {
    NONE,
    CLEARKEY,
    WIDEVINE,
    PLAYREADY
}
