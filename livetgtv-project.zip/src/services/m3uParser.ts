import { Channel, DrmType, StreamFormat } from '../types/channel';

/**
 * Extracts the EPG XMLTV URL declared in the #EXTM3U header (url-tvg or tvg-url).
 */
export function extractM3uEpgUrl(content: string): string | null {
  if (!content) return null;
  const headerMatch = content.match(/#EXTM3U[^\r\n]*/i);
  if (!headerMatch) return null;
  const header = headerMatch[0];
  const match = header.match(/(?:url-tvg|tvg-url)=["']([^"']+)["']/i);
  return match ? match[1].trim() : null;
}

export function parseM3uPlaylist(content: string): Channel[] {
  if (!content) return [];

  const lines = content.split(/\r?\n/);
  const channels: Channel[] = [];

  let currentChannel: Partial<Channel> = {};
  let currentHeaders: Record<string, string> = {};
  let currentGroup = 'General';
  let channelIndex = 1;

  for (let i = 0; i < lines.length; i++) {
    const rawLine = lines[i].trim();
    if (!rawLine || rawLine.startsWith('#EXTM3U')) {
      continue;
    }

    if (rawLine.startsWith('#EXTINF:')) {
      // If we already had an uncommitted channel with a streamUrl, save it
      if (currentChannel.streamUrl && currentChannel.name) {
        channels.push(finalizeChannel(currentChannel, currentHeaders, channelIndex++));
        currentChannel = {};
        currentHeaders = {};
      }

      // Parse #EXTINF attributes
      // Example: #EXTINF:-1 tvg-id="1132" tvg-name="Star Plus HD" tvg-logo="https://..." group-title="Entertainment", Star Plus HD
      const commaIdx = rawLine.lastIndexOf(',');
      const infoPart = commaIdx !== -1 ? rawLine.substring(0, commaIdx) : rawLine;
      const titlePart = commaIdx !== -1 ? rawLine.substring(commaIdx + 1).trim() : 'Channel';

      // Extract attributes with regex
      const tvgIdMatch = infoPart.match(/tvg-id=["']([^"']*)["']/i);
      const tvgNameMatch = infoPart.match(/tvg-name=["']([^"']*)["']/i);
      const tvgLogoMatch = infoPart.match(/tvg-logo=["']([^"']*)["']/i);
      const groupTitleMatch = infoPart.match(/group-title=["']([^"']*)["']/i);

      if (groupTitleMatch && groupTitleMatch[1]) {
        currentGroup = groupTitleMatch[1].trim() || 'General';
      }

      currentChannel.name = titlePart || tvgNameMatch?.[1] || 'Live Channel';
      currentChannel.tvgId = tvgIdMatch?.[1] || '';
      currentChannel.tvgName = tvgNameMatch?.[1] || currentChannel.name;
      currentChannel.logoUrl = tvgLogoMatch?.[1] || '';
      currentChannel.group = currentGroup;
      continue;
    }

    // Kodi / IPTV properties
    if (rawLine.startsWith('#KODIPROP:')) {
      const propContent = rawLine.replace('#KODIPROP:', '').trim();
      const eqIdx = propContent.indexOf('=');
      if (eqIdx !== -1) {
        const key = propContent.substring(0, eqIdx).trim();
        const value = propContent.substring(eqIdx + 1).trim();

        if (key === 'inputstream.adaptive.manifest_type') {
          if (value.toLowerCase().includes('mpd')) currentChannel.format = 'dash';
          else if (value.toLowerCase().includes('hls')) currentChannel.format = 'hls';
        } else if (key === 'inputstream.adaptive.license_type') {
          if (value.toLowerCase().includes('clearkey')) currentChannel.drmType = 'clearkey';
          else if (value.toLowerCase().includes('widevine')) currentChannel.drmType = 'widevine';
        } else if (key === 'inputstream.adaptive.license_key') {
          currentChannel.licenseKey = value;
        }
      }
      continue;
    }

    // VLC / HTTP options
    if (rawLine.startsWith('#EXTVLCOPT:')) {
      const optContent = rawLine.replace('#EXTVLCOPT:', '').trim();
      const eqIdx = optContent.indexOf('=');
      if (eqIdx !== -1) {
        const key = optContent.substring(0, eqIdx).trim();
        const value = optContent.substring(eqIdx + 1).trim();

        if (key === 'http-user-agent') {
          currentChannel.userAgent = value;
          currentHeaders['User-Agent'] = value;
        } else if (key === 'http-referrer') {
          currentChannel.referer = value;
          currentHeaders['Referer'] = value;
        }
      }
      continue;
    }

    // Extended HTTP options JSON
    if (rawLine.startsWith('#EXTHTTP:')) {
      const jsonContent = rawLine.replace('#EXTHTTP:', '').trim();
      try {
        const parsed = JSON.parse(jsonContent);
        if (parsed.cookie) {
          currentChannel.cookie = parsed.cookie;
          currentHeaders['Cookie'] = parsed.cookie;
        }
        if (parsed['user-agent'] || parsed.userAgent) {
          const ua = parsed['user-agent'] || parsed.userAgent;
          currentChannel.userAgent = ua;
          currentHeaders['User-Agent'] = ua;
        }
        if (parsed.headers && typeof parsed.headers === 'object') {
          Object.assign(currentHeaders, parsed.headers);
        }
      } catch (err) {
        console.warn('Could not parse #EXTHTTP JSON:', jsonContent);
      }
      continue;
    }

    // If line is a URL and not a comment
    if (!rawLine.startsWith('#') && (rawLine.startsWith('http://') || rawLine.startsWith('https://') || rawLine.includes('://'))) {
      currentChannel.streamUrl = rawLine;

      // Determine stream format if not already set by #KODIPROP
      if (!currentChannel.format) {
        if (rawLine.includes('.m3u8') || rawLine.includes('/hls/')) {
          currentChannel.format = 'hls';
        } else if (rawLine.includes('.mpd') || rawLine.includes('/dash/') || rawLine.includes('/WDVLive/')) {
          currentChannel.format = 'dash';
        } else if (rawLine.includes('.mp4')) {
          currentChannel.format = 'mp4';
        } else {
          currentChannel.format = 'unknown';
        }
      }

      if (!currentChannel.name) {
        currentChannel.name = `Channel ${channelIndex}`;
      }

      channels.push(finalizeChannel(currentChannel, currentHeaders, channelIndex++));
      currentChannel = {};
      currentHeaders = {};
    }
  }

  // Final check for remaining channel
  if (currentChannel.streamUrl && currentChannel.name) {
    channels.push(finalizeChannel(currentChannel, currentHeaders, channelIndex));
  }

  return channels;
}

function finalizeChannel(
  channel: Partial<Channel>,
  headers: Record<string, string>,
  number: number
): Channel {
  // Ensure unique ID even if multiple stream entries share the same tvg-id
  const channelId = channel.tvgId ? `${channel.tvgId}_${number}` : `ch_${number}`;
  const cleanFormat: StreamFormat = channel.format || 'unknown';
  const cleanDrm: DrmType = channel.drmType || (channel.licenseKey ? 'clearkey' : 'none');

  return {
    id: channelId,
    name: channel.name?.trim() || `Channel ${number}`,
    tvgId: channel.tvgId,
    tvgName: channel.tvgName,
    group: channel.group?.trim() || 'General',
    logoUrl: channel.logoUrl || '',
    streamUrl: channel.streamUrl || '',
    format: cleanFormat,
    drmType: cleanDrm,
    licenseKey: channel.licenseKey,
    licenseUrl: channel.licenseUrl,
    userAgent: channel.userAgent,
    cookie: channel.cookie,
    referer: channel.referer,
    extraHeaders: Object.keys(headers).length > 0 ? headers : undefined,
    channelNumber: number,
  };
}
