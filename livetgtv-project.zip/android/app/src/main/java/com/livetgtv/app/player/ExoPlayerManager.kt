package com.livetgtv.app.player

import android.content.Context
import android.net.Uri
import androidx.media3.common.C
import androidx.media3.common.Format
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.common.TrackGroup
import androidx.media3.common.TrackSelectionOverride
import androidx.media3.common.Tracks
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.okhttp.OkHttpDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.exoplayer.trackselection.DefaultTrackSelector
import com.livetgtv.app.data.model.Channel
import com.livetgtv.app.data.model.DrmType
import com.livetgtv.app.data.model.StreamFormat
import okhttp3.OkHttpClient
import java.util.concurrent.TimeUnit

@UnstableApi
class ExoPlayerManager(private val context: Context) {

    var exoPlayer: ExoPlayer? = null
        private set
    var trackSelector: DefaultTrackSelector? = null
        private set

    var currentChannel: Channel? = null
        private set

    var currentPlaybackSpeed: Float = 1.0f
        private set

    private var onPlayerStateChanged: ((PlaybackState) -> Unit)? = null

    data class TrackInfo(
        val index: Int,
        val id: String,
        val name: String,
        val language: String?,
        val bitrate: Int,
        val isSelected: Boolean
    )

    data class QualityInfo(
        val index: Int,
        val width: Int,
        val height: Int,
        val bitrate: Int,
        val frameRate: Float,
        val isSelected: Boolean
    )

    sealed class PlaybackState {
        object Idle : PlaybackState()
        object Buffering : PlaybackState()
        object Ready : PlaybackState()
        object Ended : PlaybackState()
        data class Error(val message: String, val code: Int? = null, val technicalDetails: String? = null) : PlaybackState()
    }

    fun initPlayer(listener: (PlaybackState) -> Unit): ExoPlayer {
        this.onPlayerStateChanged = listener

        if (exoPlayer == null) {
            val selector = DefaultTrackSelector(context).apply {
                parameters = buildUponParameters()
                    .setPreferredTextLanguage("en")
                    .build()
            }
            trackSelector = selector

            val player = ExoPlayer.Builder(context)
                .setTrackSelector(selector)
                .setHandleAudioBecomingNoisy(true)
                .setWakeMode(C.WAKE_MODE_NETWORK)
                .build()

            player.addListener(object : Player.Listener {
                override fun onPlaybackStateChanged(state: Int) {
                    when (state) {
                        Player.STATE_IDLE -> onPlayerStateChanged?.invoke(PlaybackState.Idle)
                        Player.STATE_BUFFERING -> onPlayerStateChanged?.invoke(PlaybackState.Buffering)
                        Player.STATE_READY -> onPlayerStateChanged?.invoke(PlaybackState.Ready)
                        Player.STATE_ENDED -> onPlayerStateChanged?.invoke(PlaybackState.Ended)
                    }
                }

                override fun onPlayerError(error: PlaybackException) {
                    val humanError = translatePlaybackError(error)
                    onPlayerStateChanged?.invoke(humanError)
                }
            })

            exoPlayer = player
        }

        return exoPlayer!!
    }

    fun playChannel(channel: Channel) {
        this.currentChannel = channel
        val player = exoPlayer ?: return

        try {
            val okHttpClient = OkHttpClient.Builder()
                .connectTimeout(15, TimeUnit.SECONDS)
                .readTimeout(20, TimeUnit.SECONDS)
                .build()

            val dataSourceFactory = OkHttpDataSource.Factory(okHttpClient)
            if (!channel.userAgent.isNullOrBlank()) {
                dataSourceFactory.setUserAgent(channel.userAgent)
            } else {
                dataSourceFactory.setUserAgent("PlayTV/7.1.5 (Linux;Android 8.1.0) ExoPlayerLib/2.11.7")
            }

            val defaultRequestProperties = mutableMapOf<String, String>()
            if (!channel.cookie.isNullOrBlank()) {
                defaultRequestProperties["Cookie"] = channel.cookie
            }
            if (!channel.referer.isNullOrBlank()) {
                defaultRequestProperties["Referer"] = channel.referer
            }
            if (channel.extraHeaders.isNotEmpty()) {
                defaultRequestProperties.putAll(channel.extraHeaders)
            }
            dataSourceFactory.setDefaultRequestProperties(defaultRequestProperties)

            val mimeType = when (channel.format) {
                StreamFormat.HLS -> MimeTypes.APPLICATION_M3U8
                StreamFormat.DASH -> MimeTypes.APPLICATION_MPD
                StreamFormat.MP4 -> MimeTypes.VIDEO_MP4
                StreamFormat.UNKNOWN -> {
                    if (channel.streamUrl.contains(".mpd")) MimeTypes.APPLICATION_MPD
                    else if (channel.streamUrl.contains(".m3u8")) MimeTypes.APPLICATION_M3U8
                    else null
                }
            }

            val mediaItemBuilder = MediaItem.Builder()
                .setUri(Uri.parse(channel.streamUrl))

            if (mimeType != null) {
                mediaItemBuilder.setMimeType(mimeType)
            }

            if (channel.drmType == DrmType.CLEARKEY && !channel.licenseKey.isNullOrBlank()) {
                mediaItemBuilder.setDrmConfiguration(
                    MediaItem.DrmConfiguration.Builder(C.CLEARKEY_NAME)
                        .setLicenseUri(channel.licenseUrl ?: "https://clearkey.default")
                        .setMultiSession(true)
                        .build()
                )
            } else if (channel.drmType == DrmType.WIDEVINE && !channel.licenseUrl.isNullOrBlank()) {
                val drmHeaders = mutableMapOf<String, String>()
                if (!channel.cookie.isNullOrBlank()) {
                    drmHeaders["Cookie"] = channel.cookie
                }
                mediaItemBuilder.setDrmConfiguration(
                    MediaItem.DrmConfiguration.Builder(C.WIDEVINE_UUID)
                        .setLicenseUri(channel.licenseUrl)
                        .setLicenseRequestHeaders(drmHeaders)
                        .build()
                )
            }

            val mediaSourceFactory = DefaultMediaSourceFactory(dataSourceFactory)
            val mediaSource = mediaSourceFactory.createMediaSource(mediaItemBuilder.build())

            player.setMediaSource(mediaSource)
            player.prepare()
            player.playWhenReady = true

        } catch (e: Exception) {
            onPlayerStateChanged?.invoke(
                PlaybackState.Error(
                    message = "Failed to initialize stream: ${e.localizedMessage}",
                    technicalDetails = e.stackTraceToString()
                )
            )
        }
    }

    fun setPlaybackSpeed(speed: Float) {
        currentPlaybackSpeed = speed
        exoPlayer?.playbackParameters = PlaybackParameters(speed)
    }

    fun seekRelative(offsetMs: Long) {
        val player = exoPlayer ?: return
        val target = (player.currentPosition + offsetMs).coerceAtLeast(0)
        player.seekTo(target)
    }

    // --- Audio Track Selection ---
    fun getAudioTracks(): List<TrackInfo> {
        val player = exoPlayer ?: return emptyList()
        val currentTracks = player.currentTracks
        val result = mutableListOf<TrackInfo>()
        var index = 0

        for (group in currentTracks.groups) {
            if (group.type == C.TRACK_TYPE_AUDIO) {
                for (i in 0 until group.length) {
                    val format = group.getTrackFormat(i)
                    val isSelected = group.isTrackSelected(i)
                    val label = format.label ?: format.language ?: "Track ${index + 1}"
                    result.add(
                        TrackInfo(
                            index = index++,
                            id = format.id ?: "$i",
                            name = label,
                            language = format.language,
                            bitrate = format.bitrate,
                            isSelected = isSelected
                        )
                    )
                }
            }
        }
        return result
    }

    fun selectAudioTrack(trackIndex: Int) {
        val selector = trackSelector ?: return
        val player = exoPlayer ?: return
        var counter = 0
        for (group in player.currentTracks.groups) {
            if (group.type == C.TRACK_TYPE_AUDIO) {
                for (i in 0 until group.length) {
                    if (counter == trackIndex) {
                        val override = TrackSelectionOverride(group.mediaTrackGroup, i)
                        selector.parameters = selector.buildUponParameters()
                            .setOverrideForType(override)
                            .build()
                        return
                    }
                    counter++
                }
            }
        }
    }

    // --- Video Quality Selection ---
    fun getVideoQualities(): List<QualityInfo> {
        val player = exoPlayer ?: return emptyList()
        val currentTracks = player.currentTracks
        val result = mutableListOf<QualityInfo>()
        var index = 0

        for (group in currentTracks.groups) {
            if (group.type == C.TRACK_TYPE_VIDEO) {
                for (i in 0 until group.length) {
                    val format = group.getTrackFormat(i)
                    val isSelected = group.isTrackSelected(i)
                    result.add(
                        QualityInfo(
                            index = index++,
                            width = format.width,
                            height = format.height,
                            bitrate = format.bitrate,
                            frameRate = format.frameRate,
                            isSelected = isSelected
                        )
                    )
                }
            }
        }
        return result
    }

    fun selectVideoQuality(qualityIndex: Int) {
        val selector = trackSelector ?: return
        val player = exoPlayer ?: return
        if (qualityIndex == -1) {
            // Auto / ABR mode
            selector.parameters = selector.buildUponParameters()
                .clearOverridesOfType(C.TRACK_TYPE_VIDEO)
                .build()
            return
        }

        var counter = 0
        for (group in player.currentTracks.groups) {
            if (group.type == C.TRACK_TYPE_VIDEO) {
                for (i in 0 until group.length) {
                    if (counter == qualityIndex) {
                        val override = TrackSelectionOverride(group.mediaTrackGroup, i)
                        selector.parameters = selector.buildUponParameters()
                            .setOverrideForType(override)
                            .build()
                        return
                    }
                    counter++
                }
            }
        }
    }

    // --- Subtitle Track Selection ---
    fun getSubtitleTracks(): List<TrackInfo> {
        val player = exoPlayer ?: return emptyList()
        val currentTracks = player.currentTracks
        val result = mutableListOf<TrackInfo>()
        var index = 0

        for (group in currentTracks.groups) {
            if (group.type == C.TRACK_TYPE_TEXT) {
                for (i in 0 until group.length) {
                    val format = group.getTrackFormat(i)
                    val isSelected = group.isTrackSelected(i)
                    val label = format.label ?: format.language ?: "Subtitles ${index + 1}"
                    result.add(
                        TrackInfo(
                            index = index++,
                            id = format.id ?: "$i",
                            name = label,
                            language = format.language,
                            bitrate = format.bitrate,
                            isSelected = isSelected
                        )
                    )
                }
            }
        }
        return result
    }

    fun selectSubtitleTrack(trackIndex: Int) {
        val selector = trackSelector ?: return
        val player = exoPlayer ?: return
        if (trackIndex == -1) {
            // Disable subtitles
            selector.parameters = selector.buildUponParameters()
                .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, true)
                .build()
            return
        }

        selector.parameters = selector.buildUponParameters()
            .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false)
            .build()

        var counter = 0
        for (group in player.currentTracks.groups) {
            if (group.type == C.TRACK_TYPE_TEXT) {
                for (i in 0 until group.length) {
                    if (counter == trackIndex) {
                        val override = TrackSelectionOverride(group.mediaTrackGroup, i)
                        selector.parameters = selector.buildUponParameters()
                            .setOverrideForType(override)
                            .build()
                        return
                    }
                    counter++
                }
            }
        }
    }

    private fun translatePlaybackError(error: PlaybackException): PlaybackState.Error {
        val errorCode = error.errorCode
        val errorMsg = when (errorCode) {
            PlaybackException.ERROR_CODE_IO_BAD_HTTP_STATUS -> {
                val httpMessage = error.message ?: ""
                if (httpMessage.contains("403")) {
                    "HTTP 403 Forbidden: Stream token expired or requires carrier network credentials."
                } else if (httpMessage.contains("404")) {
                    "HTTP 404 Not Found: Broadcast manifest URI is unavailable."
                } else {
                    "HTTP Error: $httpMessage"
                }
            }
            PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_FAILED,
            PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_TIMEOUT -> {
                "Network timeout: Connection to live stream server failed."
            }
            PlaybackException.ERROR_CODE_PARSING_CONTAINER_MALFORMED,
            PlaybackException.ERROR_CODE_PARSING_MANIFEST_MALFORMED -> {
                "Malformed Stream: The manifest or segment file could not be parsed."
            }
            PlaybackException.ERROR_CODE_DRM_LICENSE_ACQUISITION_FAILED,
            PlaybackException.ERROR_CODE_DRM_PROVISIONING_FAILED -> {
                "DRM Error: Failed to acquire valid decryption keys for this protected channel."
            }
            PlaybackException.ERROR_CODE_DECODER_INIT_FAILED -> {
                "Hardware Decoder Error: Device cannot decode video codec profile."
            }
            else -> {
                error.localizedMessage ?: "Unknown ExoPlayer playback failure"
            }
        }

        return PlaybackState.Error(
            message = errorMsg,
            code = errorCode,
            technicalDetails = error.stackTraceToString()
        )
    }

    fun release() {
        exoPlayer?.release()
        exoPlayer = null
        trackSelector = null
    }
}
