import React, { useState } from 'react';
import { Channel } from '../types/channel';
import { Star, Tv, ShieldCheck, Play, Radio } from 'lucide-react';
import { getChannelEPG } from '../services/epgService';

interface ChannelCardProps {
  channel: Channel;
  isSelected: boolean;
  isFavorite: boolean;
  onSelect: (channel: Channel) => void;
  onToggleFavorite: (channelId: string, e: React.MouseEvent) => void;
  viewMode?: 'grid' | 'compact' | 'list';
}

export const ChannelCard: React.FC<ChannelCardProps> = ({
  channel,
  isSelected,
  isFavorite,
  onSelect,
  onToggleFavorite,
  viewMode = 'grid',
}) => {
  const [imgError, setImgError] = useState(false);
  const epg = getChannelEPG(channel);

  if (viewMode === 'list') {
    return (
      <div
        onClick={() => onSelect(channel)}
        className={`group relative flex items-center justify-between p-3 rounded-xl border transition-all cursor-pointer ${
          isSelected
            ? 'bg-cyan-950/40 border-cyan-500/80 shadow-lg shadow-cyan-950/50'
            : 'bg-slate-900/60 hover:bg-slate-800/80 border-slate-800/80 hover:border-slate-700'
        }`}
      >
        <div className="flex items-center gap-3 min-w-0">
          <span className="w-8 text-xs font-mono font-bold text-slate-500 text-center shrink-0">
            #{channel.channelNumber}
          </span>

          {/* Logo container */}
          <div className="w-10 h-10 rounded-lg bg-slate-950/80 border border-slate-800 p-1 flex items-center justify-center overflow-hidden shrink-0">
            {channel.logoUrl && !imgError ? (
              <img
                src={channel.logoUrl}
                alt={channel.name}
                referrerPolicy="no-referrer"
                onError={() => setImgError(true)}
                className="max-h-full max-w-full object-contain"
              />
            ) : (
              <Tv className="w-4 h-4 text-cyan-400" />
            )}
          </div>

          <div className="min-w-0">
            <div className="flex items-center gap-2">
              <h4 className="text-sm font-semibold text-white truncate group-hover:text-cyan-300 transition-colors">
                {channel.name}
              </h4>
              {channel.drmType !== 'none' && (
                <span title="Protected Stream" className="shrink-0 flex items-center">
                  <ShieldCheck className="w-3.5 h-3.5 text-amber-400" />
                </span>
              )}
            </div>
            <p className="text-xs text-slate-400 truncate mt-0.5">
              {epg.current.title}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 shrink-0 ml-3">
          <span className="text-[11px] text-slate-400 hidden sm:inline-block">
            {channel.group}
          </span>
          <button
            onClick={(e) => onToggleFavorite(channel.id, e)}
            className={`p-2 rounded-lg transition-colors ${
              isFavorite
                ? 'text-amber-400 hover:text-amber-300'
                : 'text-slate-500 hover:text-slate-300 hover:bg-slate-800'
            }`}
            title={isFavorite ? 'Remove from favorites' : 'Add to favorites'}
          >
            <Star className={`w-4 h-4 ${isFavorite ? 'fill-current' : ''}`} />
          </button>
        </div>
      </div>
    );
  }

  return (
    <div
      onClick={() => onSelect(channel)}
      className={`group relative flex flex-col justify-between p-3.5 rounded-2xl border transition-all cursor-pointer ${
        isSelected
          ? 'bg-cyan-950/30 border-cyan-500 shadow-xl shadow-cyan-950/40 ring-1 ring-cyan-500'
          : 'bg-slate-900/60 hover:bg-slate-800/80 border-slate-800/80 hover:border-slate-700/80 hover:shadow-lg'
      }`}
    >
      {/* Top row: Channel number & Favorite */}
      <div className="flex items-center justify-between">
        <span className="text-[11px] font-mono font-bold text-slate-400 bg-slate-950/80 px-2 py-0.5 rounded-md border border-slate-800">
          CH {channel.channelNumber}
        </span>
        <button
          onClick={(e) => onToggleFavorite(channel.id, e)}
          className={`p-1.5 rounded-lg transition-colors ${
            isFavorite
              ? 'text-amber-400 hover:text-amber-300'
              : 'text-slate-500 hover:text-slate-300 hover:bg-slate-800/60'
          }`}
          title={isFavorite ? 'Remove from favorites' : 'Add to favorites'}
        >
          <Star className={`w-4 h-4 ${isFavorite ? 'fill-current' : ''}`} />
        </button>
      </div>

      {/* Middle: Logo & Name */}
      <div className="flex items-center gap-3 my-3">
        <div className="w-12 h-12 rounded-xl bg-slate-950/90 border border-slate-800 p-1.5 flex items-center justify-center overflow-hidden shrink-0 group-hover:border-slate-700 transition-colors">
          {channel.logoUrl && !imgError ? (
            <img
              src={channel.logoUrl}
              alt={channel.name}
              referrerPolicy="no-referrer"
              onError={() => setImgError(true)}
              className="max-h-full max-w-full object-contain"
            />
          ) : (
            <div className="w-full h-full flex flex-col items-center justify-center text-cyan-400">
              <Tv className="w-5 h-5 mb-0.5" />
              <span className="text-[9px] font-bold uppercase">{channel.name.slice(0, 3)}</span>
            </div>
          )}
        </div>

        <div className="min-w-0 flex-1">
          <div className="flex items-center gap-1.5">
            <h4 className="text-sm font-bold text-white tracking-tight truncate group-hover:text-cyan-300 transition-colors">
              {channel.name}
            </h4>
            {channel.drmType !== 'none' && (
              <span title="DRM Protected" className="shrink-0 flex items-center">
                <ShieldCheck className="w-3.5 h-3.5 text-amber-400" />
              </span>
            )}
          </div>
          <p className="text-[11px] text-slate-400 mt-0.5 truncate">
            {channel.group}
          </p>
        </div>
      </div>

      {/* Bottom: EPG "Now Playing" bar */}
      <div className="mt-1 pt-2 border-t border-slate-800/60">
        <div className="flex items-center justify-between text-[10px] text-slate-400 mb-1">
          <span className="truncate max-w-[130px] font-medium text-slate-300">
            {epg.current.title}
          </span>
          <span className="font-mono text-slate-500 shrink-0">
            {epg.current.endTime}
          </span>
        </div>
        <div className="w-full bg-slate-950 h-1 rounded-full overflow-hidden">
          <div
            className={`h-full transition-all ${
              isSelected ? 'bg-cyan-400' : 'bg-slate-700 group-hover:bg-cyan-600'
            }`}
            style={{ width: `${epg.current.progressPercent}%` }}
          />
        </div>
      </div>
    </div>
  );
};
