# LiveTGTV – Native Android Live TV Streaming App & Web Player

LiveTGTV is a modern, high-performance Live TV application designed for Android phones and tablets using **Kotlin**, **Jetpack Compose**, and **AndroidX Media3 ExoPlayer**, paired with a responsive web player.

## Features
- **Native Android Studio Project**: Full Gradle Kotlin DSL project targeting Android 15 (API 35).
- **Media3 ExoPlayer**: Direct HLS, MPEG-DASH, MP4 playback with custom OkHttp headers.
- **ClearKey & Widevine DRM Support**: Automatic key decryption from M3U `#KODIPROP` and custom DRM input.
- **On-Screen Touch Gestures**:
  - Vertical swipe on left side for brightness adjustment.
  - Vertical swipe on right side for volume control.
  - Tap anywhere to toggle on-screen controls overlay.
  - Double-tap sides for ±10s seek.
- **Dynamic M3U Playlist Parser**: Dynamic parsing of channel names, logos, groups, and HTTP headers from `https://livetgtv.lovable.app/api/public/playlist.m3u`.
- **EPG Program Schedule**: Real-time progress bars and "Now Playing" metadata.
- **Android Simulator & Web Player**: Test on Pixel 8, Galaxy Tab S9, and responsive desktop viewports.

## How to Build the Android App
1. Open the `android` directory in **Android Studio** (Iguana / Ladybug or newer).
2. Sync Gradle files.
3. Run or assemble the APK:
```bash
cd android
./gradlew assembleDebug
```
The APK will be generated at `app/build/outputs/apk/debug/app-debug.apk`.

## How to Run the Web Application
```bash
npm install
npm run dev
```
Open http://localhost:3000
