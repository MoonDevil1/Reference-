package com.livetgtv.app.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.livetgtv.app.data.model.Channel
import com.livetgtv.app.data.model.DrmType
import com.livetgtv.app.data.model.StreamFormat
import com.livetgtv.app.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NetworkStreamScreen(
    onPlayStream: (Channel) -> Unit,
    onBack: () -> Unit
) {
    var streamUrl by remember { mutableStateOf("") }
    var streamName by remember { mutableStateOf("") }
    var userAgent by remember { mutableStateOf("") }
    var cookie by remember { mutableStateOf("") }
    var referer by remember { mutableStateOf("") }
    var drmType by remember { mutableStateOf(DrmType.NONE) }
    var licenseKey by remember { mutableStateOf("") }
    var showAdvanced by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Network Stream Player", color = Color.White, fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = Color.White)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = DarkBackground)
            )
        },
        containerColor = DarkBackground
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(16.dp)
        ) {
            // Stream URL input
            OutlinedTextField(
                value = streamUrl,
                onValueChange = { streamUrl = it },
                label = { Text("Network Stream URL (HLS / DASH / MP4 / RTSP)") },
                placeholder = { Text("https://example.com/live/master.m3u8") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = PrimaryCyan,
                    unfocusedBorderColor = SurfaceVariantDark,
                    focusedContainerColor = SurfaceDark,
                    unfocusedContainerColor = SurfaceDark,
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White
                )
            )

            Spacer(modifier = Modifier.height(10.dp))

            OutlinedTextField(
                value = streamName,
                onValueChange = { streamName = it },
                label = { Text("Stream Label / Name (Optional)") },
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = PrimaryCyan,
                    unfocusedBorderColor = SurfaceVariantDark,
                    focusedContainerColor = SurfaceDark,
                    unfocusedContainerColor = SurfaceDark,
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White
                )
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Advanced Headers toggle
            TextButton(
                onClick = { showAdvanced = !showAdvanced }
            ) {
                Icon(
                    imageVector = if (showAdvanced) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                    contentDescription = null,
                    tint = PrimaryCyan
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    if (showAdvanced) "Hide HTTP Headers & DRM" else "Configure HTTP Headers & DRM Decryption",
                    color = PrimaryCyan,
                    fontSize = 13.sp
                )
            }

            if (showAdvanced) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(SurfaceDark, RoundedCornerShape(12.dp))
                        .padding(12.dp)
                ) {
                    OutlinedTextField(
                        value = userAgent,
                        onValueChange = { userAgent = it },
                        label = { Text("User-Agent Header") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White
                        )
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = cookie,
                        onValueChange = { cookie = it },
                        label = { Text("Cookie / HMAC Token Header") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White
                        )
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = licenseKey,
                        onValueChange = {
                            licenseKey = it
                            if (it.isNotBlank()) drmType = DrmType.CLEARKEY
                        },
                        label = { Text("ClearKey DRM key_id:key Hex Pair") },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth(),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = Color.White,
                            unfocusedTextColor = Color.White
                        )
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Play Button
            Button(
                onClick = {
                    if (streamUrl.isNotBlank()) {
                        val fmt = when {
                            streamUrl.contains(".m3u8") -> StreamFormat.HLS
                            streamUrl.contains(".mpd") -> StreamFormat.DASH
                            streamUrl.contains(".mp4") -> StreamFormat.MP4
                            else -> StreamFormat.HLS
                        }
                        val channel = Channel(
                            id = "custom_${System.currentTimeMillis()}",
                            name = if (streamName.isNotBlank()) streamName else "Custom Stream",
                            group = "Network Streams",
                            streamUrl = streamUrl.trim(),
                            format = fmt,
                            drmType = drmType,
                            licenseKey = licenseKey.ifBlank { null },
                            userAgent = userAgent.ifBlank { null },
                            cookie = cookie.ifBlank { null },
                            referer = referer.ifBlank { null },
                            channelNumber = 999
                        )
                        onPlayStream(channel)
                    }
                },
                enabled = streamUrl.isNotBlank(),
                colors = ButtonDefaults.buttonColors(containerColor = PrimaryCyan),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.fillMaxWidth().height(48.dp)
            ) {
                Icon(Icons.Default.PlayArrow, contentDescription = null, tint = Color.Black)
                Spacer(modifier = Modifier.width(8.dp))
                Text("Start Stream Playback", color = Color.Black, fontWeight = FontWeight.Bold)
            }
        }
    }
}
