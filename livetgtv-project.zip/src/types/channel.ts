export type StreamFormat = 'hls' | 'dash' | 'mp4' | 'unknown';
export type DrmType = 'none' | 'clearkey' | 'widevine' | 'playready';

export interface Channel {
  id: string;
  name: string;
  tvgId?: string;
  tvgName?: string;
  group: string;
  logoUrl?: string;
  streamUrl: string;
  format: StreamFormat;
  drmType: DrmType;
  licenseKey?: string;
  licenseUrl?: string;
  userAgent?: string;
  cookie?: string;
  referer?: string;
  extraHeaders?: Record<string, string>;
  channelNumber: number;
}

export interface EPGProgram {
  title: string;
  startTime: string; // e.g. "06:00"
  endTime: string;   // e.g. "07:30"
  progressPercent: number; // 0 to 100
  description: string;
  category: string;
  rating?: string;
  posterUrl?: string;
  startTimestamp?: number; // epoch ms
  endTimestamp?: number;   // epoch ms
  channelId?: string;
}

export interface ChannelEPGData {
  channelId: string;
  channelName?: string;
  sourceUrl: string;
  updatedAt: number;
  current: EPGProgram | null;
  upcoming: EPGProgram[];
  hasLiveMetadata: boolean;
}

export interface StreamDiagnosticsData {
  streamUrl: string;
  format: StreamFormat;
  drmType: DrmType;
  licenseKey?: string;
  userAgent?: string;
  cookie?: string;
  referer?: string;
  resolution?: string;
  bitrate?: number;
  bufferHealth?: number;
  state: 'idle' | 'buffering' | 'playing' | 'paused' | 'error';
  errorMessage?: string;
  errorCode?: number | string;
  headersSent?: Record<string, string>;
  latencyMs?: number;
}
