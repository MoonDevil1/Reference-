import React, { useState } from 'react';
import { Smartphone, Tablet, Monitor, RotateCw, Wifi, Battery, Volume2 } from 'lucide-react';

export type DeviceMode = 'responsive' | 'phone' | 'tablet' | 'tv';

interface AndroidSimulatorProps {
  deviceMode: DeviceMode;
  onDeviceModeChange: (mode: DeviceMode) => void;
  children: React.ReactNode;
}

export const AndroidSimulator: React.FC<AndroidSimulatorProps> = ({
  deviceMode,
  onDeviceModeChange,
  children,
}) => {
  const [isLandscape, setIsLandscape] = useState(false);

  const toggleOrientation = () => {
    setIsLandscape(!isLandscape);
  };

  if (deviceMode === 'responsive') {
    return <div className="w-full h-full">{children}</div>;
  }

  return (
    <div className="w-full min-h-[calc(100vh-64px)] flex flex-col items-center justify-center p-4 bg-slate-950/90 overflow-x-hidden">
      {/* Device Toolbar */}
      <div className="flex items-center gap-3 mb-4 px-4 py-2 rounded-xl bg-slate-900 border border-slate-800 text-xs shadow-lg">
        <span className="text-slate-400 font-semibold">Preview Simulation:</span>
        <div className="flex items-center gap-1 bg-slate-950 p-1 rounded-lg border border-slate-800">
          <button
            onClick={() => onDeviceModeChange('phone')}
            className={`flex items-center gap-1.5 px-3 py-1 rounded-md transition-colors ${
              deviceMode === 'phone' ? 'bg-cyan-500 text-slate-950 font-bold' : 'text-slate-400 hover:text-white'
            }`}
          >
            <Smartphone className="w-3.5 h-3.5" />
            Phone (Pixel 8)
          </button>
          <button
            onClick={() => onDeviceModeChange('tablet')}
            className={`flex items-center gap-1.5 px-3 py-1 rounded-md transition-colors ${
              deviceMode === 'tablet' ? 'bg-cyan-500 text-slate-950 font-bold' : 'text-slate-400 hover:text-white'
            }`}
          >
            <Tablet className="w-3.5 h-3.5" />
            Tablet (Tab S9)
          </button>
          <button
            onClick={() => onDeviceModeChange('responsive')}
            className={`flex items-center gap-1.5 px-3 py-1 rounded-md transition-colors ${
              (deviceMode as string) === 'responsive' ? 'bg-cyan-500 text-slate-950 font-bold' : 'text-slate-400 hover:text-white'
            }`}
          >
            <Monitor className="w-3.5 h-3.5" />
            Full Screen
          </button>
        </div>

        {deviceMode === 'phone' && (
          <button
            onClick={toggleOrientation}
            className="flex items-center gap-1.5 px-2.5 py-1 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white transition-colors"
            title="Rotate Device"
          >
            <RotateCw className="w-3.5 h-3.5" />
            {isLandscape ? 'Landscape' : 'Portrait'}
          </button>
        )}
      </div>

      {/* Simulated Device Chassis */}
      {deviceMode === 'phone' && (
        <div
          className={`relative transition-all duration-300 rounded-[44px] p-3.5 bg-slate-900 border-4 border-slate-800 shadow-[0_25px_60px_-15px_rgba(0,0,0,0.8)] ${
            isLandscape ? 'w-[780px] h-[400px]' : 'w-[380px] h-[780px]'
          }`}
        >
          {/* Bezel inner */}
          <div className="relative w-full h-full bg-slate-950 rounded-[34px] overflow-hidden flex flex-col border border-slate-800/80">
            {/* Android Status Bar */}
            <div className="h-6 w-full bg-slate-950 flex items-center justify-between px-6 text-[10px] font-mono text-slate-400 shrink-0 z-40 select-none">
              <span>09:41</span>
              {/* Punch-hole Camera */}
              <div className="w-3 h-3 rounded-full bg-black border border-slate-800" />
              <div className="flex items-center gap-1.5">
                <Wifi className="w-3 h-3" />
                <Battery className="w-3.5 h-3.5 text-emerald-400" />
              </div>
            </div>

            {/* Screen Content */}
            <div className="flex-1 overflow-y-auto relative no-scrollbar">
              {children}
            </div>

            {/* Android Gesture Bar */}
            <div className="h-4 w-full bg-slate-950 flex items-center justify-center shrink-0 z-40">
              <div className="w-28 h-1 bg-slate-600 rounded-full" />
            </div>
          </div>
        </div>
      )}

      {deviceMode === 'tablet' && (
        <div className="relative w-full max-w-5xl h-[680px] rounded-[36px] p-4 bg-slate-900 border-4 border-slate-800 shadow-[0_25px_70px_-15px_rgba(0,0,0,0.9)]">
          {/* Bezel inner */}
          <div className="relative w-full h-full bg-slate-950 rounded-[24px] overflow-hidden flex flex-col border border-slate-800">
            {/* Tablet Status Bar */}
            <div className="h-7 w-full bg-slate-950 flex items-center justify-between px-8 text-xs font-mono text-slate-400 shrink-0 border-b border-slate-900 select-none">
              <div className="flex items-center gap-2">
                <span className="font-semibold text-slate-300">LiveTGTV Tab</span>
                <span className="text-slate-600">·</span>
                <span>Android 14 (API 34)</span>
              </div>
              <div className="flex items-center gap-3">
                <span>10:30 AM</span>
                <Wifi className="w-3.5 h-3.5" />
                <Battery className="w-4 h-4 text-emerald-400" />
              </div>
            </div>

            {/* Content Area */}
            <div className="flex-1 overflow-hidden relative">
              {children}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
