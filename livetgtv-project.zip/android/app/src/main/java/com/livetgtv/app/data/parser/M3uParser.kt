package com.livetgtv.app.data.parser

import com.livetgtv.app.data.model.Channel
import com.livetgtv.app.data.model.DrmType
import com.livetgtv.app.data.model.StreamFormat
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStream
import java.io.InputStreamReader
import java.util.regex.Pattern

object M3uParser {

    private val TVG_ID_PATTERN = Pattern.compile("tvg-id=[\"']([^\"']*)[\"']", Pattern.CASE_INSENSITIVE)
    private val TVG_NAME_PATTERN = Pattern.compile("tvg-name=[\"']([^\"']*)[\"']", Pattern.CASE_INSENSITIVE)
    private val TVG_LOGO_PATTERN = Pattern.compile("tvg-logo=[\"']([^\"']*)[\"']", Pattern.CASE_INSENSITIVE)
    private val GROUP_TITLE_PATTERN = Pattern.compile("group-title=[\"']([^\"']*)[\"']", Pattern.CASE_INSENSITIVE)

    fun parse(inputStream: InputStream): List<Channel> {
        val reader = BufferedReader(InputStreamReader(inputStream))
        val channels = mutableListOf<Channel>()

        var currentChannelBuilder = ChannelBuilder()
        var currentGroup = "General"
        var channelIndex = 1

        reader.useLines { lines ->
            for (line in lines) {
                val trimmed = line.trim()
                if (trimmed.isEmpty() || trimmed.startsWith("#EXTM3U")) {
                    continue
                }

                when {
                    trimmed.startsWith("#EXTINF:") -> {
                        // If previous builder was populated with a URL, commit it
                        if (currentChannelBuilder.hasUrlAndName()) {
                            channels.add(currentChannelBuilder.build(channelIndex++))
                            currentChannelBuilder = ChannelBuilder()
                        }

                        val commaIndex = trimmed.lastIndexOf(',')
                        val infoPart = if (commaIndex != -1) trimmed.substring(0, commaIndex) else trimmed
                        val titlePart = if (commaIndex != -1) trimmed.substring(commaIndex + 1).trim() else "Channel"

                        val tvgId = extractAttribute(infoPart, TVG_ID_PATTERN)
                        val tvgName = extractAttribute(infoPart, TVG_NAME_PATTERN)
                        val tvgLogo = extractAttribute(infoPart, TVG_LOGO_PATTERN)
                        val groupTitle = extractAttribute(infoPart, GROUP_TITLE_PATTERN)

                        if (!groupTitle.isNullOrBlank()) {
                            currentGroup = groupTitle.trim()
                        }

                        currentChannelBuilder.name = if (titlePart.isNotBlank()) titlePart else tvgName ?: "Live Channel"
                        currentChannelBuilder.tvgId = tvgId
                        currentChannelBuilder.tvgName = tvgName
                        currentChannelBuilder.logoUrl = tvgLogo
                        currentChannelBuilder.group = currentGroup
                    }

                    trimmed.startsWith("#KODIPROP:") -> {
                        val prop = trimmed.removePrefix("#KODIPROP:").trim()
                        val eqIndex = prop.indexOf('=')
                        if (eqIndex != -1) {
                            val key = prop.substring(0, eqIndex).trim()
                            val value = prop.substring(eqIndex + 1).trim()
                            when (key) {
                                "inputstream.adaptive.manifest_type" -> {
                                    if (value.contains("mpd", ignoreCase = true)) {
                                        currentChannelBuilder.format = StreamFormat.DASH
                                    } else if (value.contains("hls", ignoreCase = true)) {
                                        currentChannelBuilder.format = StreamFormat.HLS
                                    }
                                }
                                "inputstream.adaptive.license_type" -> {
                                    if (value.contains("clearkey", ignoreCase = true)) {
                                        currentChannelBuilder.drmType = DrmType.CLEARKEY
                                    } else if (value.contains("widevine", ignoreCase = true)) {
                                        currentChannelBuilder.drmType = DrmType.WIDEVINE
                                    }
                                }
                                "inputstream.adaptive.license_key" -> {
                                    currentChannelBuilder.licenseKey = value
                                }
                            }
                        }
                    }

                    trimmed.startsWith("#EXTVLCOPT:") -> {
                        val opt = trimmed.removePrefix("#EXTVLCOPT:").trim()
                        val eqIndex = opt.indexOf('=')
                        if (eqIndex != -1) {
                            val key = opt.substring(0, eqIndex).trim()
                            val value = opt.substring(eqIndex + 1).trim()
                            when (key) {
                                "http-user-agent" -> currentChannelBuilder.userAgent = value
                                "http-referrer" -> currentChannelBuilder.referer = value
                            }
                        }
                    }

                    trimmed.startsWith("#EXTHTTP:") -> {
                        val jsonStr = trimmed.removePrefix("#EXTHTTP:").trim()
                        try {
                            val json = JSONObject(jsonStr)
                            if (json.has("cookie")) {
                                currentChannelBuilder.cookie = json.getString("cookie")
                            }
                            if (json.has("user-agent")) {
                                currentChannelBuilder.userAgent = json.getString("user-agent")
                            }
                        } catch (e: Exception) {
                            // Non-fatal JSON parse error
                        }
                    }

                    !trimmed.startsWith("#") && (trimmed.startsWith("http://") || trimmed.startsWith("https://")) -> {
                        currentChannelBuilder.streamUrl = trimmed

                        if (currentChannelBuilder.format == StreamFormat.UNKNOWN) {
                            currentChannelBuilder.format = when {
                                trimmed.contains(".m3u8") -> StreamFormat.HLS
                                trimmed.contains(".mpd") -> StreamFormat.DASH
                                trimmed.contains(".mp4") -> StreamFormat.MP4
                                else -> StreamFormat.HLS
                            }
                        }

                        channels.add(currentChannelBuilder.build(channelIndex++))
                        currentChannelBuilder = ChannelBuilder()
                    }
                }
            }
        }

        // Commit final channel if pending
        if (currentChannelBuilder.hasUrlAndName()) {
            channels.add(currentChannelBuilder.build(channelIndex))
        }

        return channels
    }

    private fun extractAttribute(source: String, pattern: Pattern): String? {
        val matcher = pattern.matcher(source)
        return if (matcher.find()) matcher.group(1) else null
    }

    private class ChannelBuilder {
        var name: String? = null
        var tvgId: String? = null
        var tvgName: String? = null
        var group: String = "General"
        var logoUrl: String? = null
        var streamUrl: String? = null
        var format: StreamFormat = StreamFormat.UNKNOWN
        var drmType: DrmType = DrmType.NONE
        var licenseKey: String? = null
        var licenseUrl: String? = null
        var userAgent: String? = null
        var cookie: String? = null
        var referer: String? = null

        fun hasUrlAndName(): Boolean {
            return !streamUrl.isNullOrBlank() && !name.isNullOrBlank()
        }

        fun build(number: Int): Channel {
            val id = if (!tvgId.isNullOrBlank()) "${tvgId}_${number}" else "ch_${number}"
            return Channel(
                id = id,
                name = name ?: "Channel $number",
                tvgId = tvgId,
                tvgName = tvgName,
                group = group,
                logoUrl = logoUrl,
                streamUrl = streamUrl ?: "",
                format = format,
                drmType = drmType,
                licenseKey = licenseKey,
                licenseUrl = licenseUrl,
                userAgent = userAgent,
                cookie = cookie,
                referer = referer,
                channelNumber = number
            )
        }
    }
}
