package com.livetgtv.app.data.repository

import android.content.Context
import com.livetgtv.app.data.model.Channel
import com.livetgtv.app.data.parser.M3uParser
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException
import java.util.concurrent.TimeUnit

class PlaylistRepository(private val context: Context) {

    companion object {
        const val DEFAULT_PLAYLIST_URL = "https://livetgtv.lovable.app/api/public/playlist.m3u"
        private const val CACHE_FILE_NAME = "livetgtv_playlist.m3u"
    }

    private val httpClient: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .build()

    private val cacheFile: File by lazy {
        File(context.filesDir, CACHE_FILE_NAME)
    }

    suspend fun getChannels(forceRefresh: Boolean = false, customUrl: String? = null): Result<List<Channel>> = withContext(Dispatchers.IO) {
        val targetUrl = customUrl ?: DEFAULT_PLAYLIST_URL

        // If not forcing refresh and cache exists, load from disk first
        if (!forceRefresh && cacheFile.exists() && customUrl == null) {
            try {
                FileInputStream(cacheFile).use { stream ->
                    val cachedChannels = M3uParser.parse(stream)
                    if (cachedChannels.isNotEmpty()) {
                        return@withContext Result.success(cachedChannels)
                    }
                }
            } catch (e: Exception) {
                // Ignore cache read failure and continue to network
            }
        }

        // Fetch from network
        try {
            val request = Request.Builder()
                .url(targetUrl)
                .header("User-Agent", "LiveTGTV/1.0.0 (Android ExoPlayer; Linux; en-US)")
                .header("Accept", "*/*")
                .build()

            val response = httpClient.newCall(request).execute()
            if (!response.isSuccessful) {
                // If network failed but cache is available, fallback to cache
                if (cacheFile.exists()) {
                    FileInputStream(cacheFile).use { stream ->
                        val fallback = M3uParser.parse(stream)
                        if (fallback.isNotEmpty()) {
                            return@withContext Result.success(fallback)
                        }
                    }
                }
                return@withContext Result.failure(IOException("HTTP error code: ${response.code}"))
            }

            val body = response.body ?: return@withContext Result.failure(IOException("Empty playlist body received"))
            val bytes = body.bytes()

            // Save to cache file asynchronously
            if (customUrl == null) {
                try {
                    FileOutputStream(cacheFile).use { it.write(bytes) }
                } catch (e: Exception) {
                    // Non-fatal cache write error
                }
            }

            val channels = bytes.inputStream().use { stream ->
                M3uParser.parse(stream)
            }

            Result.success(channels)
        } catch (e: Exception) {
            // Fallback to cache if available
            if (cacheFile.exists()) {
                try {
                    FileInputStream(cacheFile).use { stream ->
                        val fallback = M3uParser.parse(stream)
                        if (fallback.isNotEmpty()) {
                            return@withContext Result.success(fallback)
                        }
                    }
                } catch (ignored: Exception) {}
            }
            Result.failure(e)
        }
    }
}
