package com.livetgtv.app.ui.screens

import android.app.Activity
import android.app.PictureInPictureParams
import android.content.Context
import android.media.AudioManager
import android.os.Build
import android.util.Rational
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.Button
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import androidx.annotation.OptIn
import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import coil.load
import com.livetgtv.app.R
import com.livetgtv.app.data.model.Channel
import com.livetgtv.app.player.ExoPlayerManager
import com.livetgtv.app.ui.theme.*

@OptIn(UnstableApi::class)
@Composable
fun PlayerScreen(
    exoPlayer: ExoPlayer,
    exoPlayerManager: ExoPlayerManager,
    channel: Channel,
    channelsList: List<Channel>,
    playbackState: ExoPlayerManager.PlaybackState,
    favorites: Set<String>,
    onToggleFavorite: (String) -> Unit,
    onBack: () -> Unit,
    onSelectChannel: (Channel) -> Unit,
    onNextChannel: () -> Unit,
    onPrevChannel: () -> Unit,
    onOpenDiagnostics: () -> Unit
) {
    val context = LocalContext.current
    val activity = context as? Activity

    // Screen states
    var resizeMode by remember { mutableStateOf(AspectRatioFrameLayout.RESIZE_MODE_FIT) }
    var isChannelDrawerOpen by remember { mutableStateOf(false) }
    var isExpandedControlsOpen by remember { mutableStateOf(false) }
    var expandedControlsTab by remember { mutableStateOf("speed") } // speed, quality, audio, subtitles

    // Dynamic track info
    var audioTracks by remember { mutableStateOf<List<ExoPlayerManager.TrackInfo>>(emptyList()) }
    var videoQualities by remember { mutableStateOf<List<ExoPlayerManager.QualityInfo>>(emptyList()) }
    var subtitleTracks by remember { mutableStateOf<List<ExoPlayerManager.TrackInfo>>(emptyList()) }
    var currentSpeed by remember { mutableStateOf(exoPlayerManager.currentPlaybackSpeed) }

    // Channel drawer search & filtering
    var drawerSearchQuery by remember { mutableStateOf("") }
    var drawerSelectedCategory by remember { mutableStateOf("All") }

    val categories = remember(channelsList) {
        val list = mutableListOf("All", "Favorites")
        list.addAll(channelsList.map { it.group }.distinct().sorted())
        list
    }

    val filteredDrawerChannels = remember(channelsList, drawerSearchQuery, drawerSelectedCategory, favorites) {
        channelsList.filter { ch ->
            val matchesCategory = when (drawerSelectedCategory) {
                "All" -> true
                "Favorites" -> favorites.contains(ch.id)
                else -> ch.group.equals(drawerSelectedCategory, ignoreCase = true)
            }
            val matchesSearch = drawerSearchQuery.isBlank() ||
                    ch.name.contains(drawerSearchQuery, ignoreCase = true) ||
                    ch.channelNumber.toString() == drawerSearchQuery.trim()
            matchesCategory && matchesSearch
        }
    }

    fun enterPip() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && activity != null) {
            val params = PictureInPictureParams.Builder()
                .setAspectRatio(Rational(16, 9))
                .build()
            activity.enterPictureInPictureMode(params)
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black)
    ) {
        // Native Media3 PlayerView with custom controller layout
        AndroidView(
            factory = { ctx ->
                PlayerView(ctx).apply {
                    player = exoPlayer
                    useController = true
                    controllerShowTimeoutMs = 4500
                    setControllerLayoutId(R.layout.custom_media3_controller)
                    this.resizeMode = resizeMode
                    layoutParams = FrameLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT
                    )

                    // Bind custom views inside the controller
                    findViewById<TextView?>(R.id.channel_name_tv)?.text = channel.name
                    findViewById<TextView?>(R.id.channel_number_tv)?.text = "CH ${channel.channelNumber}"
                    findViewById<TextView?>(R.id.channel_category_tv)?.text = "${channel.group} · ${channel.format.name.uppercase()} Live"
                    findViewById<ImageView?>(R.id.channel_logo_iv)?.let { iv ->
                        if (!channel.logoUrl.isNullOrBlank()) {
                            iv.load(channel.logoUrl)
                        } else {
                            iv.setImageResource(android.R.drawable.ic_media_play)
                        }
                    }

                    // Button listeners
                    findViewById<View?>(R.id.btn_back)?.setOnClickListener { onBack() }
                    findViewById<View?>(R.id.btn_favorite)?.setOnClickListener { onToggleFavorite(channel.id) }
                    findViewById<View?>(R.id.btn_diagnostics)?.setOnClickListener { onOpenDiagnostics() }
                    
                    findViewById<View?>(R.id.btn_channel_drawer)?.setOnClickListener {
                        isChannelDrawerOpen = true
                    }

                    findViewById<Button?>(R.id.btn_playback_speed)?.let { btn ->
                        btn.text = "${currentSpeed}×"
                        btn.setOnClickListener {
                            expandedControlsTab = "speed"
                            isExpandedControlsOpen = true
                        }
                    }

                    findViewById<View?>(R.id.btn_quality)?.setOnClickListener {
                        videoQualities = exoPlayerManager.getVideoQualities()
                        expandedControlsTab = "quality"
                        isExpandedControlsOpen = true
                    }

                    findViewById<View?>(R.id.btn_audio_track)?.setOnClickListener {
                        audioTracks = exoPlayerManager.getAudioTracks()
                        expandedControlsTab = "audio"
                        isExpandedControlsOpen = true
                    }

                    findViewById<View?>(R.id.btn_subtitles)?.setOnClickListener {
                        subtitleTracks = exoPlayerManager.getSubtitleTracks()
                        expandedControlsTab = "subtitles"
                        isExpandedControlsOpen = true
                    }

                    findViewById<Button?>(R.id.btn_aspect_ratio)?.let { btn ->
                        btn.setOnClickListener {
                            resizeMode = when (resizeMode) {
                                AspectRatioFrameLayout.RESIZE_MODE_FIT -> {
                                    btn.text = "Stretch"
                                    AspectRatioFrameLayout.RESIZE_MODE_FILL
                                }
                                AspectRatioFrameLayout.RESIZE_MODE_FILL -> {
                                    btn.text = "Zoom"
                                    AspectRatioFrameLayout.RESIZE_MODE_ZOOM
                                }
                                else -> {
                                    btn.text = "Fit 16:9"
                                    AspectRatioFrameLayout.RESIZE_MODE_FIT
                                }
                            }
                            this.resizeMode = resizeMode
                        }
                    }

                    findViewById<View?>(R.id.btn_pip)?.setOnClickListener {
                        enterPip()
                    }

                    // Setup gesture tracking for Brightness (left) and Volume (right)
                    val audioManager = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
                    var startY = 0f
                    var isLeft = false
                    val hudBrightness = findViewById<View?>(R.id.hud_brightness)
                    val hudVolume = findViewById<View?>(R.id.hud_volume)
                    val hudBrightnessTv = findViewById<TextView?>(R.id.hud_brightness_tv)
                    val hudVolumeTv = findViewById<TextView?>(R.id.hud_volume_tv)

                    val gestureDetector = GestureDetector(ctx, object : GestureDetector.SimpleOnGestureListener() {
                        override fun onDoubleTap(e: MotionEvent): Boolean {
                            val width = width
                            if (e.x < width * 0.4f) {
                                exoPlayerManager.seekRelative(-10000)
                            } else if (e.x > width * 0.6f) {
                                exoPlayerManager.seekRelative(10000)
                            }
                            return true
                        }
                    })

                    setOnTouchListener { v, event ->
                        gestureDetector.onTouchEvent(event)
                        when (event.actionMasked) {
                            MotionEvent.ACTION_DOWN -> {
                                startY = event.y
                                isLeft = event.x < v.width / 2f
                            }
                            MotionEvent.ACTION_MOVE -> {
                                val deltaY = startY - event.y
                                if (Math.abs(deltaY) > 20) {
                                    if (isLeft && activity != null) {
                                        // Brightness
                                        val lp = activity.window.attributes
                                        var b = if (lp.screenBrightness < 0) 0.5f else lp.screenBrightness
                                        b = (b + deltaY / 1000f).coerceIn(0.05f, 1.0f)
                                        lp.screenBrightness = b
                                        activity.window.attributes = lp
                                        hudBrightness?.visibility = View.VISIBLE
                                        hudBrightnessTv?.text = "${(b * 100).toInt()}%"
                                    } else {
                                        // Volume
                                        val maxVol = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
                                        val curVol = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC)
                                        val newVol = (curVol + (deltaY / 80f).toInt()).coerceIn(0, maxVol)
                                        audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, newVol, 0)
                                        hudVolume?.visibility = View.VISIBLE
                                        hudVolumeTv?.text = "${((newVol.toFloat() / maxVol) * 100).toInt()}%"
                                    }
                                }
                            }
                            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                                hudBrightness?.postDelayed({ hudBrightness?.visibility = View.GONE }, 1200)
                                hudVolume?.postDelayed({ hudVolume?.visibility = View.GONE }, 1200)
                            }
                        }
                        false
                    }
                }
            },
            update = { view ->
                view.resizeMode = resizeMode
                view.findViewById<TextView?>(R.id.channel_name_tv)?.text = channel.name
                view.findViewById<TextView?>(R.id.channel_number_tv)?.text = "CH ${channel.channelNumber}"
                view.findViewById<TextView?>(R.id.channel_category_tv)?.text = "${channel.group} · ${channel.format.name.uppercase()} Live"
                view.findViewById<Button?>(R.id.btn_playback_speed)?.text = "${currentSpeed}×"
            },
            modifier = Modifier.fillMaxSize()
        )

        // Loading Overlay
        if (playbackState is ExoPlayerManager.PlaybackState.Buffering) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.5f)),
                contentAlignment = Alignment.Center
            ) {
                CircularProgressIndicator(color = PrimaryCyan)
            }
        }

        // Error State Overlay
        if (playbackState is ExoPlayerManager.PlaybackState.Error) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.88f))
                    .padding(24.dp),
                contentAlignment = Alignment.Center
            ) {
                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = SurfaceDark,
                    border = androidx.compose.foundation.BorderStroke(1.dp, SurfaceVariantDark),
                    modifier = Modifier.fillMaxWidth().wrapContentHeight()
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(
                            Icons.Default.ErrorOutline,
                            contentDescription = "Playback Error",
                            tint = LiveRed,
                            modifier = Modifier.size(48.dp)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "Stream Unavailable",
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            fontSize = 18.sp
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = playbackState.message,
                            color = TextSecondary,
                            fontSize = 13.sp,
                            lineHeight = 18.sp
                        )
                        Spacer(modifier = Modifier.height(18.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            OutlinedButton(onClick = onOpenDiagnostics) {
                                Text("Diagnostics", color = PrimaryCyan)
                            }
                            Button(
                                onClick = onBack,
                                colors = ButtonDefaults.buttonColors(containerColor = PrimaryCyan)
                            ) {
                                Text("Back to Guide", color = Color.Black, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }

        // Channel Drawer: Elegant slide-over overlay (channel switching without exiting the player)
        AnimatedVisibility(
            visible = isChannelDrawerOpen,
            enter = slideInHorizontally(initialOffsetX = { it }) + fadeIn(),
            exit = slideOutHorizontally(targetOffsetX = { it }) + fadeOut(),
            modifier = Modifier.fillMaxSize()
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.6f))
                    .clickable { isChannelDrawerOpen = false },
                contentAlignment = Alignment.CenterEnd
            ) {
                Surface(
                    modifier = Modifier
                        .fillMaxHeight()
                        .widthIn(max = 420.dp)
                        .fillMaxWidth(0.85f)
                        .clickable(enabled = false) {}, // absorb clicks
                    color = Color(0xF0070B14),
                    shape = RoundedCornerShape(topStart = 24.dp, bottomStart = 24.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0x3300E5FF))
                ) {
                    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
                        // Header
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Tv, contentDescription = null, tint = PrimaryCyan)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Channels Playlist", fontWeight = FontWeight.Bold, color = Color.White, fontSize = 16.sp)
                            }
                            IconButton(onClick = { isChannelDrawerOpen = false }) {
                                Icon(Icons.Default.Close, contentDescription = "Close", tint = Color.White)
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        // Search
                        OutlinedTextField(
                            value = drawerSearchQuery,
                            onValueChange = { drawerSearchQuery = it },
                            placeholder = { Text("Search channels...", color = TextSecondary, fontSize = 13.sp) },
                            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = TextSecondary) },
                            singleLine = true,
                            shape = RoundedCornerShape(12.dp),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = PrimaryCyan,
                                unfocusedBorderColor = SurfaceVariantDark,
                                focusedContainerColor = SurfaceDark,
                                unfocusedContainerColor = SurfaceDark,
                                focusedTextColor = Color.White,
                                unfocusedTextColor = Color.White
                            ),
                            modifier = Modifier.fillMaxWidth().height(48.dp)
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        // Category Chips
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            items(categories) { cat ->
                                val isSelected = drawerSelectedCategory == cat
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = if (isSelected) PrimaryCyan else SurfaceDark,
                                    modifier = Modifier.clickable { drawerSelectedCategory = cat }
                                ) {
                                    Text(
                                        text = cat,
                                        color = if (isSelected) Color.Black else TextPrimary,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                        fontSize = 11.sp,
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        // Channel Rows
                        LazyColumn(
                            verticalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.fillMaxSize()
                        ) {
                            items(filteredDrawerChannels, key = { it.id }) { ch ->
                                val isCurrent = ch.id == channel.id
                                Surface(
                                    shape = RoundedCornerShape(12.dp),
                                    color = if (isCurrent) Color(0xFF0C243B) else SurfaceDark,
                                    border = if (isCurrent) androidx.compose.foundation.BorderStroke(1.5.dp, PrimaryCyan) else null,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable {
                                            isChannelDrawerOpen = false
                                            onSelectChannel(ch)
                                        }
                                ) {
                                    Row(
                                        modifier = Modifier.padding(10.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = "CH ${ch.channelNumber}",
                                            fontSize = 10.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = PrimaryCyan,
                                            modifier = Modifier.width(42.dp)
                                        )

                                        Spacer(modifier = Modifier.width(8.dp))

                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(
                                                text = ch.name,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 13.sp,
                                                color = Color.White,
                                                maxLines = 1,
                                                overflow = TextOverflow.Ellipsis
                                            )
                                            Text(
                                                text = ch.group,
                                                fontSize = 11.sp,
                                                color = TextSecondary
                                            )
                                        }

                                        if (isCurrent) {
                                            Surface(
                                                shape = RoundedCornerShape(4.dp),
                                                color = PrimaryCyan
                                            ) {
                                                Text(
                                                    "PLAYING",
                                                    color = Color.Black,
                                                    fontSize = 9.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Expanded Secondary Controls Modal (Speed, Audio, Subtitles, Quality)
        if (isExpandedControlsOpen) {
            AlertDialog(
                onDismissRequest = { isExpandedControlsOpen = false },
                confirmButton = {
                    TextButton(onClick = { isExpandedControlsOpen = false }) {
                        Text("Done", color = PrimaryCyan, fontWeight = FontWeight.Bold)
                    }
                },
                title = {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = when (expandedControlsTab) {
                                "speed" -> "Playback Speed (${currentSpeed}×)"
                                "quality" -> "Video Stream Quality"
                                "audio" -> "Audio Track Selection"
                                "subtitles" -> "Subtitles & Captions"
                                else -> "Settings"
                            },
                            fontSize = 16.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }
                },
                text = {
                    Column(modifier = Modifier.fillMaxWidth()) {
                        when (expandedControlsTab) {
                            "speed" -> {
                                val speeds = listOf(0.5f, 0.75f, 1.0f, 1.25f, 1.5f, 2.0f)
                                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                    speeds.forEach { spd ->
                                        val isSel = currentSpeed == spd
                                        Surface(
                                            shape = RoundedCornerShape(8.dp),
                                            color = if (isSel) PrimaryCyan else SurfaceVariantDark,
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .clickable {
                                                    currentSpeed = spd
                                                    exoPlayerManager.setPlaybackSpeed(spd)
                                                    isExpandedControlsOpen = false
                                                }
                                        ) {
                                            Row(
                                                modifier = Modifier.padding(12.dp),
                                                horizontalArrangement = Arrangement.SpaceBetween
                                            ) {
                                                Text(
                                                    text = if (spd == 1.0f) "1.0× (Normal)" else "${spd}×",
                                                    color = if (isSel) Color.Black else Color.White,
                                                    fontWeight = FontWeight.SemiBold
                                                )
                                                if (isSel) {
                                                    Icon(Icons.Default.Check, contentDescription = null, tint = Color.Black)
                                                }
                                            }
                                        }
                                    }
                                }
                            }

                            "quality" -> {
                                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                    Surface(
                                        shape = RoundedCornerShape(8.dp),
                                        color = SurfaceVariantDark,
                                        modifier = Modifier.fillMaxWidth().clickable {
                                            exoPlayerManager.selectVideoQuality(-1)
                                            isExpandedControlsOpen = false
                                        }
                                    ) {
                                        Text("Auto (Adaptive Bitrate)", color = Color.White, modifier = Modifier.padding(12.dp))
                                    }
                                    videoQualities.forEach { q ->
                                        Surface(
                                            shape = RoundedCornerShape(8.dp),
                                            color = if (q.isSelected) PrimaryCyan else SurfaceVariantDark,
                                            modifier = Modifier.fillMaxWidth().clickable {
                                                exoPlayerManager.selectVideoQuality(q.index)
                                                isExpandedControlsOpen = false
                                            }
                                        ) {
                                            Row(
                                                modifier = Modifier.padding(12.dp),
                                                horizontalArrangement = Arrangement.SpaceBetween
                                            ) {
                                                Text("${q.height}p (${q.bitrate / 1000} kbps)", color = if (q.isSelected) Color.Black else Color.White)
                                                if (q.isSelected) Icon(Icons.Default.Check, contentDescription = null, tint = Color.Black)
                                            }
                                        }
                                    }
                                }
                            }

                            "audio" -> {
                                if (audioTracks.isEmpty()) {
                                    Text("Single standard stereo audio stream active", color = TextSecondary, fontSize = 13.sp)
                                } else {
                                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                        audioTracks.forEach { trk ->
                                            Surface(
                                                shape = RoundedCornerShape(8.dp),
                                                color = if (trk.isSelected) PrimaryCyan else SurfaceVariantDark,
                                                modifier = Modifier.fillMaxWidth().clickable {
                                                    exoPlayerManager.selectAudioTrack(trk.index)
                                                    isExpandedControlsOpen = false
                                                }
                                            ) {
                                                Row(
                                                    modifier = Modifier.padding(12.dp),
                                                    horizontalArrangement = Arrangement.SpaceBetween
                                                ) {
                                                    Text(trk.name, color = if (trk.isSelected) Color.Black else Color.White)
                                                    if (trk.isSelected) Icon(Icons.Default.Check, contentDescription = null, tint = Color.Black)
                                                }
                                            }
                                        }
                                    }
                                }
                            }

                            "subtitles" -> {
                                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                    Surface(
                                        shape = RoundedCornerShape(8.dp),
                                        color = SurfaceVariantDark,
                                        modifier = Modifier.fillMaxWidth().clickable {
                                            exoPlayerManager.selectSubtitleTrack(-1)
                                            isExpandedControlsOpen = false
                                        }
                                    ) {
                                        Text("Subtitles Off", color = Color.White, modifier = Modifier.padding(12.dp))
                                    }
                                    subtitleTracks.forEach { sub ->
                                        Surface(
                                            shape = RoundedCornerShape(8.dp),
                                            color = if (sub.isSelected) PrimaryCyan else SurfaceVariantDark,
                                            modifier = Modifier.fillMaxWidth().clickable {
                                                exoPlayerManager.selectSubtitleTrack(sub.index)
                                                isExpandedControlsOpen = false
                                            }
                                        ) {
                                            Row(
                                                modifier = Modifier.padding(12.dp),
                                                horizontalArrangement = Arrangement.SpaceBetween
                                            ) {
                                                Text(sub.name, color = if (sub.isSelected) Color.Black else Color.White)
                                                if (sub.isSelected) Icon(Icons.Default.Check, contentDescription = null, tint = Color.Black)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                },
                containerColor = SurfaceDark,
                shape = RoundedCornerShape(20.dp)
            )
        }
    }
}
