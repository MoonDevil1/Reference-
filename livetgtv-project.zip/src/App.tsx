import React, { useState, useEffect, useMemo, useCallback } from 'react';
import { Channel, StreamDiagnosticsData } from './types/channel';
import { parseM3uPlaylist, extractM3uEpgUrl } from './services/m3uParser';
import { UNIVERSAL_TEST_CHANNELS } from './services/fallbackChannels';
import { Header, AppTab } from './components/Header';
import { LivePlayer } from './components/LivePlayer';
import { ChannelCard } from './components/ChannelCard';
import { DiagnosticsModal } from './components/DiagnosticsModal';
import { AndroidSimulator, DeviceMode } from './components/AndroidSimulator';
import { AndroidProjectViewer } from './components/AndroidProjectViewer';
import { NetworkStreamHub } from './components/NetworkStreamHub';
import { EPGProgramGuide } from './components/EPGProgramGuide';
import {
  Search, RefreshCw, Star, Grid, List, Tv,
  Radio, Sparkles, AlertCircle, Heart, Film, Globe,
  ShieldCheck, Smartphone, Check, HelpCircle, Layers, Play
} from 'lucide-react';

const DEFAULT_PLAYLIST_URL = 'https://livetgtv.lovable.app/api/public/playlist.m3u';

export default function App() {
  const [channels, setChannels] = useState<Channel[]>([]);
  const [selectedChannel, setSelectedChannel] = useState<Channel | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(true);
  const [isRefreshing, setIsRefreshing] = useState<boolean>(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [playlistSource, setPlaylistSource] = useState<'livetgtv' | 'universal' | 'custom'>('livetgtv');
  const [playlistEpgUrl, setPlaylistEpgUrl] = useState<string | null>(null);

  // Search & Filtering
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedGroup, setSelectedGroup] = useState<string>('All');
  const [favorites, setFavorites] = useState<Set<string>>(() => {
    try {
      const saved = localStorage.getItem('livetgtv_favorites');
      return saved ? new Set(JSON.parse(saved)) : new Set();
    } catch {
      return new Set();
    }
  });

  // Recent channel history
  const [recentChannels, setRecentChannels] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem('livetgtv_recents');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  // App Layout & Device View
  const [activeTab, setActiveTab] = useState<AppTab>('guide');
  const [deviceMode, setDeviceMode] = useState<DeviceMode>('responsive');
  const [channelViewMode, setChannelViewMode] = useState<'grid' | 'list'>('grid');

  // Diagnostics modal
  const [diagnosticsModalOpen, setDiagnosticsModalOpen] = useState<boolean>(false);
  const [activeDiagnostics, setActiveDiagnostics] = useState<StreamDiagnosticsData>({
    streamUrl: '',
    format: 'unknown',
    drmType: 'none',
    state: 'idle',
  });

  // Floating Mini-Player on scroll
  const [showMiniPlayer, setShowMiniPlayer] = useState<boolean>(false);

  useEffect(() => {
    const handleScroll = () => {
      setShowMiniPlayer(window.scrollY > 450);
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Fetch playlist
  const loadPlaylist = useCallback(async (forceRefresh = false, customUrl?: string) => {
    setIsRefreshing(true);
    setErrorMessage(null);

    try {
      const targetUrl = customUrl || (playlistSource === 'universal' ? '' : `/api/playlist?refresh=${forceRefresh}`);

      if (playlistSource === 'universal' || !targetUrl) {
        setChannels(UNIVERSAL_TEST_CHANNELS);
        if (!selectedChannel && UNIVERSAL_TEST_CHANNELS.length > 0) {
          setSelectedChannel(UNIVERSAL_TEST_CHANNELS[0]);
        }
        setIsLoading(false);
        setIsRefreshing(false);
        return;
      }

      const response = await fetch(targetUrl);
      if (!response.ok) {
        throw new Error(`Failed to load playlist (Status ${response.status})`);
      }

      const m3uText = await response.text();
      const extractedEpg = extractM3uEpgUrl(m3uText);
      if (extractedEpg) {
        setPlaylistEpgUrl(extractedEpg);
      }
      const parsed = parseM3uPlaylist(m3uText);

      if (parsed.length === 0) {
        throw new Error('No valid channel entries found in playlist');
      }

      // Merge verified 24/7 working streams with the LiveTGTV playlist
      // This ensures immediate, guaranteed live playback on any network while retaining all 400+ channels
      const combined = [
        ...UNIVERSAL_TEST_CHANNELS,
        ...parsed.map((c, idx) => ({
          ...c,
          channelNumber: UNIVERSAL_TEST_CHANNELS.length + idx + 1,
        })),
      ];

      setChannels(combined);

      if (!selectedChannel && combined.length > 0) {
        // Auto-select verified working stream for immediate playback
        setSelectedChannel(combined[0]);
      }
    } catch (err: any) {
      console.error('Error loading playlist:', err);
      setErrorMessage(
        err.message || 'Network error fetching LiveTGTV playlist. Universal Live Feeds are active.'
      );
      if (channels.length === 0) {
        setChannels(UNIVERSAL_TEST_CHANNELS);
        setSelectedChannel(UNIVERSAL_TEST_CHANNELS[0]);
      }
    } finally {
      setIsLoading(false);
      setIsRefreshing(false);
    }
  }, [playlistSource, selectedChannel, channels.length]);

  useEffect(() => {
    loadPlaylist();
  }, [loadPlaylist]);

  // Persist favorites
  const toggleFavorite = (channelId: string, e: React.MouseEvent) => {
    e.stopPropagation();
    setFavorites((prev) => {
      const updated = new Set(prev);
      if (updated.has(channelId)) {
        updated.delete(channelId);
      } else {
        updated.add(channelId);
      }
      try {
        localStorage.setItem('livetgtv_favorites', JSON.stringify(Array.from(updated)));
      } catch {}
      return updated;
    });
  };

  // Channel Selection with Recents tracking
  const handleSelectChannel = (channel: Channel) => {
    setSelectedChannel(channel);
    setRecentChannels((prev) => {
      const updated = [channel.id, ...prev.filter((id) => id !== channel.id)].slice(0, 10);
      try {
        localStorage.setItem('livetgtv_recents', JSON.stringify(updated));
      } catch {}
      return updated;
    });
  };

  // Play custom network stream
  const handlePlayNetworkStream = (channel: Channel) => {
    setSelectedChannel(channel);
    setActiveTab('guide'); // Switch to player & guide view so user can watch immediately
  };

  // Categories list
  const availableCategories = useMemo(() => {
    const set = new Set<string>();
    channels.forEach((c) => {
      const g = c.group?.trim();
      if (g && g.toLowerCase() !== 'all' && g.toLowerCase() !== 'favorites') {
        set.add(g);
      }
    });
    const sorted = Array.from(set).sort();
    return ['All', 'Verified Feeds', 'Favorites', ...sorted];
  }, [channels]);

  // Filtered Channels
  const filteredChannels = useMemo(() => {
    return channels.filter((c) => {
      const matchesSearch =
        !searchQuery.trim() ||
        c.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        c.group.toLowerCase().includes(searchQuery.toLowerCase()) ||
        c.channelNumber.toString() === searchQuery.trim();

      const matchesGroup =
        selectedGroup === 'All'
          ? true
          : selectedGroup === 'Verified Feeds'
          ? c.id.startsWith('universal-')
          : selectedGroup === 'Favorites'
          ? favorites.has(c.id)
          : c.group.toLowerCase() === selectedGroup.toLowerCase();

      return matchesSearch && matchesGroup;
    });
  }, [channels, searchQuery, selectedGroup, favorites]);

  // Quick Zapper handlers (Next / Prev)
  const handleNextChannel = () => {
    if (channels.length === 0) return;
    const currentIdx = channels.findIndex((c) => c.id === selectedChannel?.id);
    const nextIdx = (currentIdx + 1) % channels.length;
    handleSelectChannel(channels[nextIdx]);
  };

  const handlePrevChannel = () => {
    if (channels.length === 0) return;
    const currentIdx = channels.findIndex((c) => c.id === selectedChannel?.id);
    const prevIdx = (currentIdx - 1 + channels.length) % channels.length;
    handleSelectChannel(channels[prevIdx]);
  };

  const openDiagnosticsForCurrent = (diag?: StreamDiagnosticsData) => {
    if (diag) {
      setActiveDiagnostics(diag);
    } else if (selectedChannel) {
      setActiveDiagnostics({
        streamUrl: selectedChannel.streamUrl,
        format: selectedChannel.format,
        drmType: selectedChannel.drmType,
        licenseKey: selectedChannel.licenseKey,
        userAgent: selectedChannel.userAgent,
        cookie: selectedChannel.cookie,
        referer: selectedChannel.referer,
        state: 'idle',
      });
    }
    setDiagnosticsModalOpen(true);
  };

  return (
    <div className="min-h-screen bg-[#090d16] text-slate-100 flex flex-col font-sans selection:bg-cyan-500/30">
      {/* Header */}
      <Header
        activeTab={activeTab}
        onTabChange={(tab) => setActiveTab(tab)}
        deviceMode={deviceMode}
        onDeviceModeChange={setDeviceMode}
        onRefreshPlaylist={() => loadPlaylist(true)}
        isRefreshing={isRefreshing}
      />

      {/* Main Content Area */}
      <main className="flex-1 w-full flex flex-col">
        {activeTab === 'project' ? (
          <AndroidProjectViewer />
        ) : activeTab === 'stream' ? (
          <div className="w-full flex-1">
            <NetworkStreamHub
              onPlayStream={handlePlayNetworkStream}
              currentChannel={selectedChannel}
            />
          </div>
        ) : (
          <AndroidSimulator
            deviceMode={deviceMode}
            onDeviceModeChange={setDeviceMode}
          >
            <div className="w-full max-w-7xl mx-auto p-4 sm:p-6 flex flex-col gap-6">
              {/* Broadcast Hero / Theater Stage */}
              <div className="w-full grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch">
                {/* Main Live Player Viewport (8 cols on Desktop) */}
                <div className="lg:col-span-8 flex flex-col">
                  <div className="w-full aspect-video rounded-2xl bg-black border border-slate-800 shadow-2xl overflow-hidden relative">
                    <LivePlayer
                      channel={selectedChannel}
                      onNextChannel={handleNextChannel}
                      onPrevChannel={handlePrevChannel}
                      onOpenDiagnostics={openDiagnosticsForCurrent}
                      onSelectUniversalChannel={() => {
                        const workingStream = channels.find((c) => c.id.startsWith('universal-')) || UNIVERSAL_TEST_CHANNELS[0];
                        setSelectedChannel(workingStream);
                      }}
                    />
                  </div>
                </div>

                {/* Live Channel Info & Broadcast Quick-Switch Deck (4 cols on Desktop) */}
                <div className="lg:col-span-4 flex flex-col justify-between p-5 rounded-2xl bg-slate-900/80 border border-slate-800 shadow-xl relative overflow-hidden">
                  <div className="space-y-4">
                    {/* Channel Header */}
                    {selectedChannel ? (
                      <div>
                        <div className="flex items-center justify-between mb-2">
                          <span className="text-xs font-mono font-bold text-cyan-400 bg-cyan-950/60 px-2 py-0.5 rounded border border-cyan-800/40">
                            CHANNEL #{selectedChannel.channelNumber}
                          </span>
                          <div className="flex items-center gap-1.5">
                            {selectedChannel.drmType !== 'none' && (
                              <span className="text-[10px] font-mono text-amber-300 bg-amber-950/60 px-2 py-0.5 rounded border border-amber-800/40 flex items-center gap-1">
                                <ShieldCheck className="w-3 h-3" /> CLEARKEY
                              </span>
                            )}
                            <button
                              onClick={(e) => toggleFavorite(selectedChannel.id, e)}
                              className={`p-1.5 rounded-lg border transition-colors ${
                                favorites.has(selectedChannel.id)
                                  ? 'border-amber-500/40 text-amber-400 bg-amber-950/30'
                                  : 'border-slate-800 text-slate-400 hover:text-white'
                              }`}
                              title="Toggle Favorite"
                            >
                              <Star className={`w-4 h-4 ${favorites.has(selectedChannel.id) ? 'fill-current' : ''}`} />
                            </button>
                          </div>
                        </div>

                        <h2 className="text-xl font-bold text-white tracking-tight flex items-center gap-2">
                          {selectedChannel.name}
                        </h2>
                        <p className="text-xs text-slate-400 mt-1 flex items-center gap-2">
                          <span>{selectedChannel.group}</span>
                          <span>·</span>
                          <span className="font-mono uppercase">{selectedChannel.format} Stream</span>
                        </p>
                      </div>
                    ) : (
                      <div>
                        <h2 className="text-lg font-bold text-white">Select Channel</h2>
                        <p className="text-xs text-slate-400">Pick any stream from the list below</p>
                      </div>
                    )}

                    {/* Stream Health Indicator */}
                    <div className="p-3.5 rounded-xl bg-slate-950/80 border border-slate-800/80 space-y-2 text-xs">
                      <div className="flex items-center justify-between">
                        <span className="text-slate-400">Media Engine:</span>
                        <span className="font-mono text-cyan-400 font-semibold">
                          Media3 ExoPlayer 1.5.1
                        </span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-slate-400">Gesture Controls:</span>
                        <span className="font-mono text-emerald-400 font-semibold">
                          Active (Swipe / Tap)
                        </span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-slate-400">Total Channels:</span>
                        <span className="font-mono text-white font-semibold">
                          {channels.length} Streams Loaded
                        </span>
                      </div>
                    </div>

                    {/* Quick Channel Jumpers & Custom Stream Button */}
                    <div className="space-y-2">
                      <div className="grid grid-cols-2 gap-2">
                        <button
                          onClick={handlePrevChannel}
                          className="px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-white text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors"
                        >
                          Channel Prev ▲
                        </button>
                        <button
                          onClick={handleNextChannel}
                          className="px-3 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-white text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors"
                        >
                          Channel Next ▼
                        </button>
                      </div>

                      <button
                        onClick={() => setActiveTab('stream')}
                        className="w-full py-2 rounded-xl bg-slate-800/70 hover:bg-slate-700 text-slate-300 hover:text-white text-xs font-semibold flex items-center justify-center gap-1.5 transition-colors border border-slate-700/60"
                      >
                        <Play className="w-3.5 h-3.5 text-cyan-400 fill-current" />
                        Open Network Stream URL Input
                      </button>
                    </div>
                  </div>

                  {/* Diagnostics Trigger Button */}
                  <div className="pt-4 mt-4 border-t border-slate-800/80 flex items-center gap-2">
                    <button
                      onClick={() => openDiagnosticsForCurrent()}
                      className="w-full py-2.5 rounded-xl bg-cyan-950/40 hover:bg-cyan-900/50 text-cyan-300 border border-cyan-800/40 text-xs font-semibold flex items-center justify-center gap-2 transition-colors"
                    >
                      <ShieldCheck className="w-4 h-4 text-cyan-400" />
                      Stream Diagnostics & Headers
                    </button>
                  </div>
                </div>
              </div>

              {/* Electronic Program Guide (Live XMLTV Data Fetcher & Schedule) */}
              <EPGProgramGuide
                channel={selectedChannel}
                playlistEpgUrl={playlistEpgUrl}
              />

              {/* Quick Channel Zapper Ribbon (Horizontal Live Carousel) */}
              <div className="w-full p-4 rounded-2xl bg-slate-900/40 border border-slate-800/80 space-y-2.5">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Radio className="w-3.5 h-3.5 text-cyan-400 animate-pulse" />
                    <span className="text-xs font-bold text-white tracking-wider uppercase">Quick Channel Zapper</span>
                  </div>
                  <span className="text-[11px] text-slate-400">Click any channel to tune instantly</span>
                </div>

                <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
                  {channels.slice(0, 14).map((c) => {
                    const isCur = selectedChannel?.id === c.id;
                    return (
                      <button
                        key={c.id}
                        onClick={() => handleSelectChannel(c)}
                        className={`group flex items-center gap-2.5 px-3 py-2 rounded-xl border text-left shrink-0 transition-all ${
                          isCur
                            ? 'bg-cyan-950/70 border-cyan-500 text-white shadow-md shadow-cyan-950/40 ring-1 ring-cyan-500'
                            : 'bg-slate-900/80 hover:bg-slate-800/90 border-slate-800/80 text-slate-300 hover:text-white'
                        }`}
                      >
                        <div className="w-7 h-7 rounded-lg bg-slate-950 border border-slate-800 p-0.5 flex items-center justify-center shrink-0">
                          {c.logoUrl ? (
                            <img
                              src={c.logoUrl}
                              alt={c.name}
                              className="max-h-full max-w-full object-contain"
                              onError={(e) => {
                                (e.target as HTMLElement).style.display = 'none';
                              }}
                            />
                          ) : (
                            <span className="text-[9px] font-mono font-bold text-cyan-400">{c.channelNumber}</span>
                          )}
                        </div>
                        <div className="flex flex-col min-w-0">
                          <span className="text-xs font-semibold truncate max-w-[120px] group-hover:text-cyan-300 transition-colors">
                            {c.name}
                          </span>
                          <span className="text-[10px] text-slate-400 font-mono">
                            CH {c.channelNumber}
                          </span>
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Channel Guide & Search Controls */}
              <div className="space-y-4 pt-2">
                {/* Search & View Controls Bar */}
                <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
                  <div className="relative flex-1 max-w-md">
                    <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
                    <input
                      type="text"
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      placeholder="Search channels by name, group, or channel #..."
                      className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-slate-900 border border-slate-800 text-xs text-white placeholder-slate-400 focus:outline-none focus:border-cyan-500 transition-colors"
                    />
                    {searchQuery && (
                      <button
                        onClick={() => setSearchQuery('')}
                        className="absolute right-3 top-1/2 -translate-y-1/2 text-xs text-slate-400 hover:text-white"
                      >
                        Clear
                      </button>
                    )}
                  </div>

                  <div className="flex items-center gap-2 self-end sm:self-auto">
                    <span className="text-xs text-slate-400 font-mono hidden sm:inline-block">
                      {filteredChannels.length} channels
                    </span>

                    <div className="flex items-center gap-1 bg-slate-900 p-1 rounded-xl border border-slate-800">
                      <button
                        onClick={() => setChannelViewMode('grid')}
                        className={`p-1.5 rounded-lg transition-colors ${
                          channelViewMode === 'grid'
                            ? 'bg-cyan-500 text-slate-950'
                            : 'text-slate-400 hover:text-white'
                        }`}
                        title="Grid View"
                      >
                        <Grid className="w-4 h-4" />
                      </button>
                      <button
                        onClick={() => setChannelViewMode('list')}
                        className={`p-1.5 rounded-lg transition-colors ${
                          channelViewMode === 'list'
                            ? 'bg-cyan-500 text-slate-950'
                            : 'text-slate-400 hover:text-white'
                        }`}
                        title="List View"
                      >
                        <List className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                </div>

                {/* Category Horizontal Filter Bar */}
                <div className="flex items-center gap-1.5 overflow-x-auto pb-2 no-scrollbar">
                  {availableCategories.map((group) => {
                    const isSelected = selectedGroup === group;
                    return (
                      <button
                        key={group}
                        onClick={() => setSelectedGroup(group)}
                        className={`px-3.5 py-1.5 text-xs font-semibold rounded-xl whitespace-nowrap shrink-0 transition-colors ${
                          isSelected
                            ? 'bg-cyan-500 text-slate-950 shadow-md shadow-cyan-500/20 font-bold'
                            : 'bg-slate-900/90 text-slate-300 hover:bg-slate-800 hover:text-white border border-slate-800/80'
                        }`}
                      >
                        {group === 'Favorites' ? `★ Favorites (${favorites.size})` : group}
                      </button>
                    );
                  })}
                </div>

                {/* Error Banner */}
                {errorMessage && (
                  <div className="p-4 rounded-xl bg-amber-950/30 border border-amber-800/50 text-amber-200 text-xs flex items-center justify-between gap-3">
                    <div className="flex items-center gap-2">
                      <AlertCircle className="w-4 h-4 shrink-0 text-amber-400" />
                      <span>{errorMessage}</span>
                    </div>
                    <button
                      onClick={() => {
                        setPlaylistSource('universal');
                        setChannels(UNIVERSAL_TEST_CHANNELS);
                        setSelectedChannel(UNIVERSAL_TEST_CHANNELS[0]);
                      }}
                      className="px-3 py-1 bg-amber-500 text-slate-950 font-bold rounded-lg text-xs hover:opacity-90 shrink-0"
                    >
                      Use Open Feeds
                    </button>
                  </div>
                )}

                {/* Channel Cards Grid */}
                {isLoading && channels.length === 0 ? (
                  <div className="py-20 flex flex-col items-center justify-center text-slate-400 space-y-3">
                    <div className="w-10 h-10 rounded-full border-3 border-cyan-500/30 border-t-cyan-400 animate-spin" />
                    <p className="text-xs font-semibold text-slate-300">
                      Parsing LiveTGTV M3U channel playlist...
                    </p>
                  </div>
                ) : filteredChannels.length === 0 ? (
                  <div className="py-16 text-center text-slate-400 bg-slate-900/40 rounded-2xl border border-slate-800/60 p-8">
                    <Tv className="w-10 h-10 mx-auto text-slate-600 mb-2" />
                    <p className="text-sm font-semibold text-white">No Channels Found</p>
                    <p className="text-xs text-slate-400 mt-1">
                      Try adjusting your search query or switching to &quot;All&quot; categories.
                    </p>
                  </div>
                ) : channelViewMode === 'grid' ? (
                  <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-3 sm:gap-4">
                    {filteredChannels.map((channel) => (
                      <ChannelCard
                        key={channel.id}
                        channel={channel}
                        isSelected={selectedChannel?.id === channel.id}
                        isFavorite={favorites.has(channel.id)}
                        onSelect={handleSelectChannel}
                        onToggleFavorite={toggleFavorite}
                        viewMode="grid"
                      />
                    ))}
                  </div>
                ) : (
                  <div className="space-y-2">
                    {filteredChannels.map((channel) => (
                      <ChannelCard
                        key={channel.id}
                        channel={channel}
                        isSelected={selectedChannel?.id === channel.id}
                        isFavorite={favorites.has(channel.id)}
                        onSelect={handleSelectChannel}
                        onToggleFavorite={toggleFavorite}
                        viewMode="list"
                      />
                    ))}
                  </div>
                )}
              </div>
            </div>
          </AndroidSimulator>
        )}
      </main>

      {/* Floating Mini-Player (When scrolled past player) */}
      {showMiniPlayer && selectedChannel && activeTab === 'guide' && deviceMode === 'responsive' && (
        <div
          onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
          className="fixed bottom-6 right-6 z-40 p-3 rounded-2xl bg-slate-900/95 backdrop-blur-md border border-cyan-500/60 shadow-2xl shadow-cyan-950/80 flex items-center gap-3.5 cursor-pointer hover:border-cyan-400 transition-all transform hover:-translate-y-1 animate-in fade-in slide-in-from-bottom-4 duration-200"
          title="Scroll back to live player"
        >
          <div className="w-11 h-11 rounded-xl bg-black border border-slate-800 p-1 flex items-center justify-center overflow-hidden shrink-0">
            {selectedChannel.logoUrl ? (
              <img
                src={selectedChannel.logoUrl}
                alt={selectedChannel.name}
                className="max-h-full max-w-full object-contain"
                onError={(e) => {
                  (e.target as HTMLElement).style.display = 'none';
                }}
              />
            ) : (
              <Tv className="w-5 h-5 text-cyan-400" />
            )}
          </div>
          <div className="flex flex-col text-left">
            <div className="flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-rose-500 animate-pulse" />
              <span className="text-[10px] font-mono text-cyan-400 font-bold">CH {selectedChannel.channelNumber}</span>
            </div>
            <span className="text-xs font-bold text-white max-w-[150px] truncate">{selectedChannel.name}</span>
            <span className="text-[10px] text-slate-400">Return to Live Player ↑</span>
          </div>
        </div>
      )}

      {/* Diagnostics Modal */}
      <DiagnosticsModal
        channel={selectedChannel}
        diagnostics={activeDiagnostics}
        isOpen={diagnosticsModalOpen}
        onClose={() => setDiagnosticsModalOpen(false)}
      />
    </div>
  );
}
