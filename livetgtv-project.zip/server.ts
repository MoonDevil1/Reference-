import express from 'express';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import zlib from 'zlib';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json());

// Memory cache for playlist to ensure high responsiveness
let cachedPlaylist: string | null = null;
let lastFetchTime = 0;
const CACHE_TTL = 10 * 60 * 1000; // 10 minutes

const PRIMARY_PLAYLIST_URL = 'https://livetgtv.lovable.app/api/public/playlist.m3u';
const DEFAULT_EPG_URL = 'https://avkb.short.gy/jioepg.xml.gz';

/* -------------------------------------------------------------
 * EPG (Electronic Program Guide) Parser & Cache
 * ----------------------------------------------------------- */
interface RawEpgProgramme {
  channel: string;
  startMs: number;
  stopMs: number;
  title: string;
  desc: string;
  category: string;
  icon?: string;
  rating?: string;
}

interface EpgCacheData {
  url: string;
  fetchedAt: number;
  programmesByChannel: Map<string, RawEpgProgramme[]>;
  channelNamesToId: Map<string, string>;
  idToDisplayName: Map<string, string>;
}

let epgCache: EpgCacheData | null = null;
let epgFetchPromise: Promise<EpgCacheData> | null = null;
const EPG_CACHE_TTL = 30 * 60 * 1000; // 30 minutes

function decodeHtml(str: string): string {
  if (!str) return '';
  return str
    .replace(/&amp;/g, '&')
    .replace(/&lt;/g, '<')
    .replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .replace(/&apos;/g, "'")
    .replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g, '$1')
    .trim();
}

function parseXmltvDate(dStr: string): number | null {
  if (!dStr) return null;
  const m = dStr.trim().match(/^(\d{4})(\d{2})(\d{2})(\d{2})(\d{2})(\d{2})(?:\s*([+-]\d{4}))?/);
  if (!m) return null;
  const [_, y, mo, d, h, mi, s, tz] = m;
  let utc = Date.UTC(parseInt(y, 10), parseInt(mo, 10) - 1, parseInt(d, 10), parseInt(h, 10), parseInt(mi, 10), parseInt(s, 10));
  if (tz) {
    const sign = tz[0] === '-' ? -1 : 1;
    const tzH = parseInt(tz.slice(1, 3), 10);
    const tzM = parseInt(tz.slice(3, 5), 10);
    utc -= sign * (tzH * 60 + tzM) * 60 * 1000;
  }
  return utc;
}

function formatTimeHHMM(ms: number): string {
  const date = new Date(ms);
  // Format to standard 2-digit HH:MM in user friendly format
  const hours = date.getHours().toString().padStart(2, '0');
  const minutes = date.getMinutes().toString().padStart(2, '0');
  return `${hours}:${minutes}`;
}

async function fetchAndIndexEpg(epgUrl: string, force = false): Promise<EpgCacheData> {
  const now = Date.now();
  if (!force && epgCache && epgCache.url === epgUrl && now - epgCache.fetchedAt < EPG_CACHE_TTL) {
    return epgCache;
  }

  if (epgFetchPromise) {
    return epgFetchPromise;
  }

  epgFetchPromise = (async () => {
    try {
      console.log(`[EPG] Fetching XMLTV data from ${epgUrl}...`);
      const response = await fetch(epgUrl, {
        headers: {
          'User-Agent': 'LiveTGTV/1.0.0 (Linux; Android 14; EPG Fetcher)',
          'Accept': '*/*',
        },
        redirect: 'follow',
      });

      if (!response.ok) {
        throw new Error(`EPG fetch failed with status ${response.status} ${response.statusText}`);
      }

      const buffer = Buffer.from(await response.arrayBuffer());
      let xmlText = '';

      // Check for Gzip magic bytes 0x1f 0x8b or .gz URL
      const isGzip = (buffer.length > 2 && buffer[0] === 0x1f && buffer[1] === 0x8b) || epgUrl.endsWith('.gz');
      if (isGzip) {
        console.log(`[EPG] Decompressing ${buffer.length} bytes gzip data...`);
        xmlText = zlib.gunzipSync(buffer).toString('utf-8');
      } else {
        xmlText = buffer.toString('utf-8');
      }

      console.log(`[EPG] XMLTV uncompressed size: ${(xmlText.length / 1024 / 1024).toFixed(2)} MB. Indexing programmes...`);

      const programmesByChannel = new Map<string, RawEpgProgramme[]>();
      const channelNamesToId = new Map<string, string>();
      const idToDisplayName = new Map<string, string>();

      // Index channels: <channel id="1136"><display-name>Star Utsav Movies</display-name>
      const channelRegex = /<channel\s+id="([^"]+)"[^>]*>([\s\S]*?)<\/channel>/g;
      let chMatch: RegExpExecArray | null;
      while ((chMatch = channelRegex.exec(xmlText)) !== null) {
        const id = chMatch[1].trim();
        const inner = chMatch[2];
        const nameMatch = inner.match(/<display-name[^>]*>([\s\S]*?)<\/display-name>/i);
        if (nameMatch && nameMatch[1]) {
          const displayName = decodeHtml(nameMatch[1]);
          idToDisplayName.set(id, displayName);
          const normalized = displayName.toLowerCase().replace(/[^a-z0-9]/g, '');
          if (normalized) {
            channelNamesToId.set(normalized, id);
          }
        }
      }

      // Index programmes
      const progRegex = /<programme\s+start="([^"]+)"\s+stop="([^"]+)"\s+channel="([^"]+)"[^>]*>([\s\S]*?)<\/programme>/g;
      let pMatch: RegExpExecArray | null;
      let totalIndexed = 0;

      while ((pMatch = progRegex.exec(xmlText)) !== null) {
        const startStr = pMatch[1];
        const stopStr = pMatch[2];
        const chId = pMatch[3].trim();
        const inner = pMatch[4];

        const startMs = parseXmltvDate(startStr);
        const stopMs = parseXmltvDate(stopStr);

        if (!startMs || !stopMs) continue;

        const titleMatch = inner.match(/<title[^>]*>([\s\S]*?)<\/title>/i);
        const descMatch = inner.match(/<desc[^>]*>([\s\S]*?)<\/desc>/i);
        const catMatch = inner.match(/<category[^>]*>([\s\S]*?)<\/category>/i);
        const iconMatch = inner.match(/<icon\s+src="([^"]+)"/i);
        const ratingMatch = inner.match(/<rating[^>]*>[\s\S]*?<value>([\s\S]*?)<\/value>[\s\S]*?<\/rating>/i);

        const prog: RawEpgProgramme = {
          channel: chId,
          startMs,
          stopMs,
          title: decodeHtml(titleMatch ? titleMatch[1] : 'Scheduled Broadcast'),
          desc: decodeHtml(descMatch ? descMatch[1] : 'Live programming broadcast on LiveTGTV.'),
          category: decodeHtml(catMatch ? catMatch[1] : 'General'),
          icon: iconMatch ? iconMatch[1].trim() : undefined,
          rating: ratingMatch ? decodeHtml(ratingMatch[1]) : undefined,
        };

        if (!programmesByChannel.has(chId)) {
          programmesByChannel.set(chId, []);
        }
        programmesByChannel.get(chId)!.push(prog);
        totalIndexed++;
      }

      // Sort programmes per channel by start time
      for (const [_, progs] of programmesByChannel) {
        progs.sort((a, b) => a.startMs - b.startMs);
      }

      console.log(`[EPG] Indexed ${totalIndexed} programmes across ${programmesByChannel.size} channels.`);

      epgCache = {
        url: epgUrl,
        fetchedAt: Date.now(),
        programmesByChannel,
        channelNamesToId,
        idToDisplayName,
      };

      return epgCache;
    } finally {
      epgFetchPromise = null;
    }
  })();

  return epgFetchPromise;
}

// Pre-warm EPG in background on startup
setTimeout(() => {
  fetchAndIndexEpg(DEFAULT_EPG_URL).catch((err) => console.warn('[EPG] Background pre-warm failed:', err.message));
}, 2000);

// API route to query EPG for a specific channel or get overview
app.get('/api/epg', async (req, res) => {
  const customUrl = typeof req.query.url === 'string' && req.query.url.trim() ? req.query.url.trim() : DEFAULT_EPG_URL;
  const forceRefresh = req.query.refresh === 'true';
  const rawChannelQuery = typeof req.query.channelId === 'string' ? req.query.channelId.trim() : '';
  const channelNameQuery = typeof req.query.channelName === 'string' ? req.query.channelName.trim() : '';

  try {
    const data = await fetchAndIndexEpg(customUrl, forceRefresh);
    const now = Date.now();

    // If no channel requested, return EPG summary / status
    if (!rawChannelQuery && !channelNameQuery) {
      return res.json({
        ok: true,
        sourceUrl: data.url,
        updatedAt: data.fetchedAt,
        totalChannels: data.programmesByChannel.size,
        availableChannelIds: Array.from(data.programmesByChannel.keys()).slice(0, 50),
      });
    }

    // Try resolving channel ID
    // 1. Exact match in programmes
    let targetChannelId = rawChannelQuery;
    let progs = data.programmesByChannel.get(targetChannelId);

    // 2. If channel ID has underscore suffix e.g. "1132_1", extract primary part "1132"
    if (!progs && targetChannelId.includes('_')) {
      const stripped = targetChannelId.split('_')[0];
      if (data.programmesByChannel.has(stripped)) {
        targetChannelId = stripped;
        progs = data.programmesByChannel.get(stripped);
      }
    }

    // 3. Match by channel name lookup
    if (!progs && channelNameQuery) {
      const normalized = channelNameQuery.toLowerCase().replace(/[^a-z0-9]/g, '');
      const mappedId = data.channelNamesToId.get(normalized);
      if (mappedId && data.programmesByChannel.has(mappedId)) {
        targetChannelId = mappedId;
        progs = data.programmesByChannel.get(mappedId);
      }
    }

    // 4. Fuzzy match channel name in idToDisplayName
    if (!progs && (channelNameQuery || rawChannelQuery)) {
      const queryKey = (channelNameQuery || rawChannelQuery).toLowerCase();
      for (const [id, name] of data.idToDisplayName.entries()) {
        if (name.toLowerCase().includes(queryKey) || queryKey.includes(name.toLowerCase())) {
          targetChannelId = id;
          progs = data.programmesByChannel.get(id);
          break;
        }
      }
    }

    if (!progs || progs.length === 0) {
      return res.json({
        channelId: rawChannelQuery,
        channelName: channelNameQuery || data.idToDisplayName.get(targetChannelId) || 'Channel',
        sourceUrl: data.url,
        updatedAt: data.fetchedAt,
        current: null,
        upcoming: [],
        totalAvailable: 0,
        hasLiveMetadata: false,
      });
    }

    // Find current and upcoming programmes
    let currentRaw: RawEpgProgramme | null = null;
    const upcomingRaw: RawEpgProgramme[] = [];

    for (const p of progs) {
      if (p.startMs <= now && now < p.stopMs) {
        currentRaw = p;
      } else if (p.startMs > now) {
        upcomingRaw.push(p);
        if (upcomingRaw.length >= 12) break; // up to 12 upcoming shows
      }
    }

    // If current was not found (e.g. tiny schedule gap), take the closest upcoming or latest finished
    if (!currentRaw && upcomingRaw.length > 0 && Math.abs(upcomingRaw[0].startMs - now) < 15 * 60 * 1000) {
      currentRaw = upcomingRaw.shift()!;
    } else if (!currentRaw && progs.length > 0) {
      // Pick the program closest to current time
      currentRaw = progs[progs.length - 1];
    }

    const formatProgram = (p: RawEpgProgramme) => {
      const durationMs = Math.max(60000, p.stopMs - p.startMs);
      const elapsedMs = Math.max(0, now - p.startMs);
      const remainingMs = Math.max(0, p.stopMs - now);
      const progressPercent = Math.min(100, Math.max(0, Math.round((elapsedMs / durationMs) * 100)));

      return {
        title: p.title,
        description: p.desc,
        category: p.category,
        startTime: formatTimeHHMM(p.startMs),
        endTime: formatTimeHHMM(p.stopMs),
        startTimestamp: p.startMs,
        endTimestamp: p.stopMs,
        progressPercent,
        durationMinutes: Math.round(durationMs / 60000),
        remainingMinutes: Math.round(remainingMs / 60000),
        posterUrl: p.icon,
        rating: p.rating,
        channelId: p.channel,
      };
    };

    return res.json({
      channelId: targetChannelId,
      channelName: data.idToDisplayName.get(targetChannelId) || channelNameQuery || `Channel ${targetChannelId}`,
      sourceUrl: data.url,
      updatedAt: data.fetchedAt,
      current: currentRaw ? formatProgram(currentRaw) : null,
      upcoming: upcomingRaw.map(formatProgram),
      totalAvailable: progs.length,
      hasLiveMetadata: true,
    });
  } catch (error: any) {
    console.error('[EPG] Error serving EPG request:', error);
    return res.status(500).json({
      channelId: rawChannelQuery,
      sourceUrl: customUrl,
      error: error.message || 'Failed to process EPG data',
      hasLiveMetadata: false,
      current: null,
      upcoming: [],
    });
  }
});

// API route to fetch and serve the M3U playlist with CORS headers
app.get('/api/playlist', async (req, res) => {
  const forceRefresh = req.query.refresh === 'true';
  const customUrl = typeof req.query.url === 'string' ? req.query.url : null;
  const targetUrl = customUrl || PRIMARY_PLAYLIST_URL;

  try {
    const now = Date.now();
    if (!customUrl && !forceRefresh && cachedPlaylist && (now - lastFetchTime < CACHE_TTL)) {
      res.setHeader('Content-Type', 'text/plain; charset=utf-8');
      res.setHeader('Access-Control-Allow-Origin', '*');
      res.setHeader('X-Cache', 'HIT');
      return res.send(cachedPlaylist);
    }

    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 12000);

    const response = await fetch(targetUrl, {
      headers: {
        'User-Agent': 'LiveTGTV/1.0.0 (Android ExoPlayer; Linux; en-US)',
        'Accept': '*/*',
      },
      signal: controller.signal,
    });
    clearTimeout(timeout);

    if (!response.ok) {
      throw new Error(`Playlist server responded with status: ${response.status} ${response.statusText}`);
    }

    const text = await response.text();
    if (!customUrl) {
      cachedPlaylist = text;
      lastFetchTime = now;
    }

    res.setHeader('Content-Type', 'text/plain; charset=utf-8');
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('X-Cache', 'MISS');
    return res.send(text);
  } catch (error: any) {
    console.error('Error fetching playlist:', error);
    // If cache exists, return it even if expired as fallback
    if (cachedPlaylist) {
      res.setHeader('Content-Type', 'text/plain; charset=utf-8');
      res.setHeader('Access-Control-Allow-Origin', '*');
      res.setHeader('X-Cache', 'STALE');
      return res.send(cachedPlaylist);
    }

    return res.status(502).json({
      error: 'Failed to retrieve LiveTGTV playlist',
      message: error.message || 'Network error fetching remote M3U',
      targetUrl,
    });
  }
});

// Stream connectivity probe endpoint to test streams safely
app.get('/api/probe-stream', async (req, res) => {
  const streamUrl = req.query.url as string;
  if (!streamUrl) {
    return res.status(400).json({ error: 'Missing stream URL' });
  }

  try {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), 6000);

    const headers: Record<string, string> = {
      'User-Agent': (req.query.userAgent as string) || 'PlayTV/7.1.5 (Linux;Android 8.1.0) ExoPlayerLib/2.11.7',
      'Accept': '*/*',
    };

    if (req.query.referer) {
      headers['Referer'] = req.query.referer as string;
    }

    const response = await fetch(streamUrl, {
      method: 'HEAD',
      headers,
      signal: controller.signal,
    });
    clearTimeout(timeout);

    res.json({
      status: response.status,
      ok: response.ok,
      contentType: response.headers.get('content-type'),
      contentLength: response.headers.get('content-length'),
      corsAllowed: response.headers.get('access-control-allow-origin') !== null,
    });
  } catch (error: any) {
    res.status(500).json({
      status: 0,
      ok: false,
      error: error.message || 'Probe request failed',
    });
  }
});

// Download full project ZIP endpoint
app.get('/api/download-project.zip', (_req, res) => {
  const zipPath = path.resolve(__dirname, 'livetgtv-project.zip');
  if (fs.existsSync(zipPath)) {
    res.setHeader('Content-Type', 'application/zip');
    res.setHeader('Content-Disposition', 'attachment; filename="livetgtv-project.zip"');
    return res.sendFile(zipPath);
  }

  const fallbackPath = path.resolve(__dirname, 'public', 'livetgtv-project.zip');
  if (fs.existsSync(fallbackPath)) {
    res.setHeader('Content-Type', 'application/zip');
    res.setHeader('Content-Disposition', 'attachment; filename="livetgtv-project.zip"');
    return res.sendFile(fallbackPath);
  }

  return res.status(404).json({ error: 'Project ZIP file not generated yet' });
});

async function startServer() {
  const isProduction = process.env.NODE_ENV === 'production';

  if (!isProduction) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(PORT, () => {
    console.log(`LiveTGTV Server running on port ${PORT}`);
  });
}

startServer();
