package com.livetgtv.app

import android.app.PictureInPictureParams
import android.content.res.Configuration
import android.os.Build
import android.os.Bundle
import android.util.Rational
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.annotation.OptIn
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.lifecycle.lifecycleScope
import androidx.media3.common.util.UnstableApi
import com.livetgtv.app.data.model.Channel
import com.livetgtv.app.data.repository.PlaylistRepository
import com.livetgtv.app.player.ExoPlayerManager
import com.livetgtv.app.ui.screens.HomeScreen
import com.livetgtv.app.ui.screens.PlayerScreen
import com.livetgtv.app.ui.theme.DarkBackground
import com.livetgtv.app.ui.theme.LiveTGTVTheme
import kotlinx.coroutines.launch

@OptIn(UnstableApi::class)
class MainActivity : ComponentActivity() {

    private lateinit var playlistRepository: PlaylistRepository
    private lateinit var exoPlayerManager: ExoPlayerManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Keep screen awake for continuous live TV streaming
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        playlistRepository = PlaylistRepository(this)
        exoPlayerManager = ExoPlayerManager(this)

        setContent {
            LiveTGTVTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = DarkBackground
                ) {
                    var channels by remember { mutableStateOf<List<Channel>>(emptyList()) }
                    var isLoading by remember { mutableStateOf(true) }
                    var errorMessage by remember { mutableStateOf<String?>(null) }
                    var selectedChannel by remember { mutableStateOf<Channel?>(null) }
                    var favorites by remember { mutableStateOf<Set<String>>(emptySet()) }
                    var playbackState by remember { mutableStateOf<ExoPlayerManager.PlaybackState>(ExoPlayerManager.PlaybackState.Idle) }

                    val player = remember {
                        exoPlayerManager.initPlayer { state ->
                            playbackState = state
                        }
                    }

                    fun loadPlaylist(forceRefresh: Boolean = false) {
                        isLoading = true
                        errorMessage = null
                        lifecycleScope.launch {
                            val result = playlistRepository.getChannels(forceRefresh)
                            isLoading = false
                            result.onSuccess { list ->
                                channels = list
                            }.onFailure { error ->
                                errorMessage = error.localizedMessage ?: "Failed to load playlist"
                            }
                        }
                    }

                    LaunchedEffect(Unit) {
                        loadPlaylist()
                    }

                    if (selectedChannel == null) {
                        HomeScreen(
                            channels = channels,
                            isLoading = isLoading,
                            errorMessage = errorMessage,
                            selectedChannel = selectedChannel,
                            favorites = favorites,
                            onChannelSelect = { channel ->
                                selectedChannel = channel
                                exoPlayerManager.playChannel(channel)
                            },
                            onToggleFavorite = { channelId ->
                                favorites = if (favorites.contains(channelId)) {
                                    favorites - channelId
                                } else {
                                    favorites + channelId
                                }
                            },
                            onRefresh = { loadPlaylist(forceRefresh = true) }
                        )
                    } else {
                        val currentIdx = channels.indexOfFirst { it.id == selectedChannel!!.id }
                        PlayerScreen(
                            exoPlayer = player,
                            exoPlayerManager = exoPlayerManager,
                            channel = selectedChannel!!,
                            channelsList = channels,
                            playbackState = playbackState,
                            favorites = favorites,
                            onToggleFavorite = { channelId ->
                                favorites = if (favorites.contains(channelId)) {
                                    favorites - channelId
                                } else {
                                    favorites + channelId
                                }
                            },
                            onBack = {
                                selectedChannel = null
                                player.stop()
                            },
                            onSelectChannel = { channel ->
                                selectedChannel = channel
                                exoPlayerManager.playChannel(channel)
                            },
                            onNextChannel = {
                                if (channels.isNotEmpty() && currentIdx != -1) {
                                    val nextChannel = channels[(currentIdx + 1) % channels.size]
                                    selectedChannel = nextChannel
                                    exoPlayerManager.playChannel(nextChannel)
                                }
                            },
                            onPrevChannel = {
                                if (channels.isNotEmpty() && currentIdx != -1) {
                                    val prevChannel = channels[(currentIdx - 1 + channels.size) % channels.size]
                                    selectedChannel = prevChannel
                                    exoPlayerManager.playChannel(prevChannel)
                                }
                            },
                            onOpenDiagnostics = {
                                // Diagnostic inspection
                            }
                        )
                    }
                }
            }
        }
    }

    override fun onUserLeaveHint() {
        super.onUserLeaveHint()
        // Enter Picture-in-Picture if a stream is playing
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O && exoPlayerManager.currentChannel != null) {
            val params = PictureInPictureParams.Builder()
                .setAspectRatio(Rational(16, 9))
                .build()
            enterPictureInPictureMode(params)
        }
    }

    override fun onPictureInPictureModeChanged(isInPictureInPictureMode: Boolean, newConfig: Configuration) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig)
    }

    override fun onDestroy() {
        super.onDestroy()
        exoPlayerManager.release()
    }
}
