import React from 'react';

interface LogoProps {
  className?: string;
  size?: 'sm' | 'md' | 'lg' | 'xl';
  showText?: boolean;
}

export const LiveTgtvIcon: React.FC<{ size?: number; className?: string }> = ({ size = 28, className = '' }) => {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 48 48"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
    >
      <defs>
        <linearGradient id="liveTvGrad" x1="0" y1="0" x2="48" y2="48" gradientUnits="userSpaceOnUse">
          <stop stopColor="#06b6d4" />
          <stop offset="0.5" stopColor="#3b82f6" />
          <stop offset="1" stopColor="#8b5cf6" />
        </linearGradient>
        <linearGradient id="screenGrad" x1="6" y1="8" x2="42" y2="38" gradientUnits="userSpaceOnUse">
          <stop stopColor="#1e293b" />
          <stop offset="1" stopColor="#0f172a" />
        </linearGradient>
      </defs>
      {/* Outer Glow TV Frame */}
      <rect x="4" y="6" width="40" height="30" rx="8" stroke="url(#liveTvGrad)" strokeWidth="2.5" />
      <rect x="7" y="9" width="34" height="24" rx="5" fill="url(#screenGrad)" />
      {/* Antenna elements */}
      <path d="M16 2L21 6" stroke="url(#liveTvGrad)" strokeWidth="2" strokeLinecap="round" />
      <path d="M32 2L27 6" stroke="url(#liveTvGrad)" strokeWidth="2" strokeLinecap="round" />
      {/* TV Stand Base */}
      <path d="M20 36L18 42H30L28 36" stroke="url(#liveTvGrad)" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
      {/* Dynamic Play / Broadcast Prism */}
      <path d="M20 16L32 21L20 26V16Z" fill="url(#liveTvGrad)" />
      {/* Live Broadcast Waves */}
      <circle cx="37" cy="13" r="2.5" fill="#ef4444" />
    </svg>
  );
};

export const LiveTgtvLogo: React.FC<LogoProps> = ({ size = 'md', showText = true, className = '' }) => {
  const iconSizes = {
    sm: 22,
    md: 28,
    lg: 38,
    xl: 52,
  };

  const textSizes = {
    sm: 'text-base',
    md: 'text-xl',
    lg: 'text-2xl',
    xl: 'text-3xl',
  };

  return (
    <div className={`flex items-center gap-2.5 ${className}`}>
      <div className="relative shrink-0 flex items-center justify-center p-1 rounded-xl bg-slate-900/80 border border-slate-800 shadow-lg shadow-cyan-500/10">
        <LiveTgtvIcon size={iconSizes[size]} />
      </div>
      {showText && (
        <div className="flex flex-col leading-none">
          <div className={`font-extrabold tracking-tight ${textSizes[size]} text-white flex items-center gap-1`}>
            <span className="text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-blue-500">
              Live
            </span>
            <span className="text-white">TGTV</span>
          </div>
          <span className="text-[10px] tracking-wider text-slate-400 uppercase font-medium mt-0.5">
            Android Media3
          </span>
        </div>
      )}
    </div>
  );
};

export default LiveTgtvLogo;
