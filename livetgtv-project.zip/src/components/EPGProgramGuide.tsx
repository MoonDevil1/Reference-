import React, { useState, useEffect, useRef } from 'react';
import {
  Clock,
  Calendar,
  Tv,
  RefreshCw,
  Sparkles,
  ChevronRight,
  Info,
  SlidersHorizontal,
  Check,
  AlertCircle,
  Film,
} from 'lucide-react';
import { Channel, ChannelEPGData, EPGProgram } from '../types/channel';
import {
  fetchChannelEPG,
  calculateProgramProgress,
  DEFAULT_XMLTV_URL,
} from '../services/xmltvService';

interface EPGProgramGuideProps {
  channel: Channel | null;
  playlistEpgUrl?: string | null;
}

export const EPGProgramGuide: React.FC<EPGProgramGuideProps> = ({
  channel,
  playlistEpgUrl,
}) => {
  const [epgData, setEpgData] = useState<ChannelEPGData | null>(null);
  const [loading, setLoading] = useState(false);
  const [activeEpgUrl, setActiveEpgUrl] = useState<string>(
    playlistEpgUrl || DEFAULT_XMLTV_URL
  );
  const [showUrlModal, setShowUrlModal] = useState(false);
  const [customUrlInput, setCustomUrlInput] = useState(activeEpgUrl);
  const [selectedUpcoming, setSelectedUpcoming] = useState<EPGProgram | null>(null);
  const [liveProgress, setLiveProgress] = useState<{
    progressPercent: number;
    remainingMinutes: number;
    elapsedMinutes: number;
  }>({ progressPercent: 0, remainingMinutes: 0, elapsedMinutes: 0 });

  // Keep active URL in sync if playlist supplies one
  useEffect(() => {
    if (playlistEpgUrl && playlistEpgUrl !== activeEpgUrl) {
      setActiveEpgUrl(playlistEpgUrl);
      setCustomUrlInput(playlistEpgUrl);
    }
  }, [playlistEpgUrl]);

  // Load EPG when channel or source changes
  const loadEpg = async (force = false) => {
    if (!channel) return;
    setLoading(true);
    try {
      const data = await fetchChannelEPG(channel, {
        epgUrl: activeEpgUrl,
        forceRefresh: force,
      });
      setEpgData(data);
      if (data.current?.startTimestamp && data.current?.endTimestamp) {
        setLiveProgress(
          calculateProgramProgress(
            data.current.startTimestamp,
            data.current.endTimestamp
          )
        );
      }
    } catch (err) {
      console.error('Failed to load EPG:', err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadEpg(false);
  }, [channel?.id, activeEpgUrl]);

  // Live timer tick every 10 seconds to advance progress bar and remaining time smoothly
  useEffect(() => {
    const timer = setInterval(() => {
      if (epgData?.current?.startTimestamp && epgData?.current?.endTimestamp) {
        const stats = calculateProgramProgress(
          epgData.current.startTimestamp,
          epgData.current.endTimestamp
        );
        setLiveProgress(stats);

        // If the current show ended (progress reached 100%), reload schedule
        if (Date.now() >= epgData.current.endTimestamp) {
          loadEpg(true);
        }
      }
    }, 10000);

    return () => clearInterval(timer);
  }, [epgData?.current]);

  if (!channel) {
    return (
      <div className="w-full p-6 rounded-2xl bg-slate-900/40 border border-slate-800/80 text-center text-slate-400 text-sm">
        Select a channel above to load live Electronic Program Guide (EPG).
      </div>
    );
  }

  const current = epgData?.current;
  const upcoming = epgData?.upcoming || [];
  const sourceFileName = activeEpgUrl.split('/').pop() || 'jioepg.xml.gz';

  return (
    <div className="w-full space-y-4">
      {/* EPG Toolbar Header */}
      <div className="flex flex-wrap items-center justify-between gap-3 p-3.5 rounded-2xl bg-slate-900/60 border border-slate-800/90 backdrop-blur-sm">
        <div className="flex items-center gap-2.5 min-w-0">
          <div className="w-8 h-8 rounded-lg bg-cyan-950/80 border border-cyan-800/60 flex items-center justify-center shrink-0 text-cyan-400">
            <Tv className="w-4 h-4" />
          </div>
          <div className="min-w-0">
            <div className="flex items-center gap-2">
              <span className="text-xs font-bold text-white uppercase tracking-wider">
                Electronic Program Guide
              </span>
              {epgData?.hasLiveMetadata ? (
                <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-950/80 text-emerald-400 border border-emerald-800/60 flex items-center gap-1 font-semibold">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
                  XMLTV LIVE
                </span>
              ) : (
                <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-800/90 text-slate-400 border border-slate-700/60">
                  SCHEDULE SYNC
                </span>
              )}
            </div>
            <p className="text-[11px] text-slate-400 truncate max-w-sm sm:max-w-md">
              Source: <span className="font-mono text-cyan-400">{sourceFileName}</span>
              {channel.tvgId ? ` · ID: #${channel.tvgId}` : ''}
            </p>
          </div>
        </div>

        {/* Action Controls */}
        <div className="flex items-center gap-2">
          <button
            onClick={() => setShowUrlModal(true)}
            className="px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white text-xs font-semibold flex items-center gap-1.5 transition-colors border border-slate-700/60"
            title="Configure Custom XMLTV Source"
          >
            <SlidersHorizontal className="w-3.5 h-3.5 text-cyan-400" />
            <span className="hidden sm:inline">XMLTV Source</span>
          </button>

          <button
            onClick={() => loadEpg(true)}
            disabled={loading}
            className="px-3 py-1.5 rounded-xl bg-cyan-950/50 hover:bg-cyan-900/60 text-cyan-300 border border-cyan-800/60 text-xs font-semibold flex items-center gap-1.5 transition-colors disabled:opacity-50"
            title="Refresh EPG Schedule"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${loading ? 'animate-spin' : ''}`} />
            <span>{loading ? 'Syncing...' : 'Refresh'}</span>
          </button>
        </div>
      </div>

      {/* Main EPG Display: Now Playing & Upcoming Schedule */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        {/* NOW PLAYING CARD (7 cols on desktop) */}
        <div className="lg:col-span-7 p-5 rounded-2xl bg-gradient-to-br from-slate-900/90 via-slate-900/80 to-[#0c1424] border border-slate-800 shadow-xl relative overflow-hidden flex flex-col justify-between">
          {/* Ambient Glow */}
          <div className="absolute top-0 right-0 w-48 h-48 bg-cyan-500/5 rounded-full blur-3xl pointer-events-none" />

          <div>
            {/* Top Bar: Now Playing status & category */}
            <div className="flex items-center justify-between gap-2 mb-3">
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-red-500 animate-pulse" />
                <span className="text-[11px] font-bold uppercase tracking-wider text-red-400 font-mono">
                  Now Playing
                </span>
                <span className="text-slate-600">·</span>
                <span className="text-xs font-semibold text-cyan-400">
                  {current?.category || 'General Broadcast'}
                </span>
              </div>

              {current?.rating && (
                <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-800/90 text-amber-300 border border-slate-700 font-semibold">
                  {current.rating}
                </span>
              )}
            </div>

            {/* Program Title & Poster */}
            <div className="flex items-start gap-4">
              {current?.posterUrl && (
                <div className="w-20 h-28 sm:w-24 sm:h-32 rounded-xl overflow-hidden bg-slate-950 border border-slate-800 shrink-0 shadow-md">
                  <img
                    src={current.posterUrl}
                    alt={current.title}
                    className="w-full h-full object-cover"
                    onError={(e) => {
                      (e.target as HTMLElement).style.display = 'none';
                    }}
                  />
                </div>
              )}

              <div className="space-y-2 flex-1 min-w-0">
                <h3 className="text-lg sm:text-xl font-bold text-white tracking-tight leading-snug line-clamp-2">
                  {current?.title || 'Live Broadcast Transmission'}
                </h3>

                {/* Broadcast Time Range */}
                <div className="flex items-center gap-3 text-xs text-slate-300 font-mono">
                  <div className="flex items-center gap-1.5 text-cyan-300">
                    <Clock className="w-3.5 h-3.5" />
                    <span>
                      {current?.startTime || '--:--'} – {current?.endTime || '--:--'}
                    </span>
                  </div>

                  {liveProgress.remainingMinutes > 0 && (
                    <span className="text-slate-400">
                      ({liveProgress.remainingMinutes} min left)
                    </span>
                  )}
                </div>

                {/* Synopsis / Description */}
                <p className="text-xs text-slate-300/90 leading-relaxed line-clamp-3 sm:line-clamp-4 pt-1">
                  {current?.description ||
                    'Broadcasting continuous live digital television signal.'}
                </p>
              </div>
            </div>
          </div>

          {/* Progress Bar & Timeline Footer */}
          <div className="mt-5 pt-4 border-t border-slate-800/80 space-y-2">
            <div className="flex items-center justify-between text-[11px] text-slate-400 font-mono">
              <span>{current?.startTime || '00:00'}</span>
              <span className="text-cyan-400 font-semibold">
                {liveProgress.progressPercent}% completed
              </span>
              <span>{current?.endTime || '00:00'}</span>
            </div>

            <div className="w-full h-2 rounded-full bg-slate-800/80 overflow-hidden relative">
              <div
                className="h-full bg-gradient-to-r from-cyan-500 via-teal-400 to-blue-500 rounded-full transition-all duration-700 ease-out"
                style={{ width: `${liveProgress.progressPercent}%` }}
              />
            </div>
          </div>
        </div>

        {/* UPCOMING SHOWS TIMELINE (5 cols on desktop) */}
        <div className="lg:col-span-5 p-5 rounded-2xl bg-slate-900/80 border border-slate-800 shadow-xl flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-3.5">
              <div className="flex items-center gap-2">
                <Calendar className="w-4 h-4 text-cyan-400" />
                <h4 className="text-xs font-bold uppercase tracking-wider text-white">
                  Up Next on {channel.name}
                </h4>
              </div>
              <span className="text-[11px] text-slate-400 font-mono">
                {upcoming.length} scheduled
              </span>
            </div>

            {/* Upcoming List */}
            {upcoming.length > 0 ? (
              <div className="space-y-2 max-h-[300px] overflow-y-auto pr-1 scrollbar-thin">
                {upcoming.slice(0, 6).map((prog, idx) => {
                  const isSelected = selectedUpcoming?.title === prog.title;
                  return (
                    <div
                      key={`${prog.title}-${idx}`}
                      onClick={() => setSelectedUpcoming(isSelected ? null : prog)}
                      className={`group p-2.5 rounded-xl border text-left transition-all cursor-pointer ${
                        isSelected
                          ? 'bg-cyan-950/40 border-cyan-500/60 shadow-sm'
                          : 'bg-slate-950/50 hover:bg-slate-800/60 border-slate-800/80 hover:border-slate-700'
                      }`}
                    >
                      <div className="flex items-start justify-between gap-2">
                        <div className="flex items-start gap-2.5 min-w-0">
                          <span className="px-1.5 py-0.5 rounded bg-slate-800 border border-slate-700/60 text-[10px] font-mono text-cyan-300 shrink-0 font-semibold">
                            {prog.startTime}
                          </span>
                          <div className="min-w-0">
                            <h5 className="text-xs font-semibold text-slate-200 group-hover:text-cyan-300 transition-colors truncate">
                              {prog.title}
                            </h5>
                            <span className="text-[10px] text-slate-400">
                              {prog.category}
                              {prog.rating ? ` · ${prog.rating}` : ''}
                            </span>
                          </div>
                        </div>

                        <ChevronRight
                          className={`w-3.5 h-3.5 text-slate-500 transition-transform shrink-0 ${
                            isSelected ? 'rotate-90 text-cyan-400' : 'group-hover:text-slate-300'
                          }`}
                        />
                      </div>

                      {/* Expandable Synopsis */}
                      {isSelected && (
                        <div className="mt-2.5 pt-2 border-t border-slate-800/70 text-[11px] text-slate-300/90 leading-relaxed animate-fadeIn">
                          <p>{prog.description}</p>
                          <div className="mt-2 text-[10px] text-cyan-400 font-mono">
                            Time Slot: {prog.startTime} – {prog.endTime}
                          </div>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            ) : (
              <div className="py-8 text-center text-xs text-slate-400 space-y-2">
                <Info className="w-5 h-5 mx-auto text-slate-500" />
                <p>No further shows listed in current XMLTV window.</p>
              </div>
            )}
          </div>

          <div className="mt-4 pt-3 border-t border-slate-800/80 flex items-center justify-between text-[11px] text-slate-400">
            <span>Schedule auto-updates live</span>
            <span className="font-mono text-slate-400">Timezone: Local System</span>
          </div>
        </div>
      </div>

      {/* Custom XMLTV URL Modal */}
      {showUrlModal && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="w-full max-w-lg rounded-2xl bg-[#090e1a] border border-slate-800 shadow-2xl p-6 space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <SlidersHorizontal className="w-4 h-4 text-cyan-400" />
                <h3 className="text-sm font-bold text-white uppercase tracking-wider">
                  Configure XMLTV Source
                </h3>
              </div>
              <button
                onClick={() => setShowUrlModal(false)}
                className="text-slate-400 hover:text-white text-xs px-2 py-1"
              >
                ✕
              </button>
            </div>

            <p className="text-xs text-slate-300">
              Enter any standard XMLTV file URL (supports uncompressed{' '}
              <code className="text-cyan-400">.xml</code> or gzip-compressed{' '}
              <code className="text-cyan-400">.xml.gz</code>). The server automatically
              downloads, decompresses, and indexes it.
            </p>

            <div className="space-y-1.5">
              <label className="text-[11px] font-mono text-slate-400">
                EPG XMLTV URL:
              </label>
              <input
                type="text"
                value={customUrlInput}
                onChange={(e) => setCustomUrlInput(e.target.value)}
                placeholder="https://example.com/epg.xml.gz"
                className="w-full px-3.5 py-2.5 rounded-xl bg-slate-950 border border-slate-800 text-xs text-white placeholder-slate-500 focus:outline-none focus:border-cyan-500 font-mono transition-colors"
              />
            </div>

            {/* Quick Presets */}
            <div className="space-y-1">
              <span className="text-[10px] text-slate-400 uppercase font-mono">
                Suggested Presets:
              </span>
              <div className="flex flex-col gap-1.5">
                <button
                  type="button"
                  onClick={() => setCustomUrlInput('https://avkb.short.gy/jioepg.xml.gz')}
                  className="text-left text-xs p-2 rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-300 hover:text-cyan-300 font-mono truncate"
                >
                  ⚡ JioTV EPG (avkb.short.gy/jioepg.xml.gz)
                </button>
                <button
                  type="button"
                  onClick={() =>
                    setCustomUrlInput('https://mitthu786.github.io/tvepg/jiotv/epg.xml.gz')
                  }
                  className="text-left text-xs p-2 rounded-lg bg-slate-900 hover:bg-slate-800 border border-slate-800 text-slate-300 hover:text-cyan-300 font-mono truncate"
                >
                  🌐 GitHub Direct Mirror (epg.xml.gz)
                </button>
              </div>
            </div>

            <div className="flex items-center justify-end gap-2.5 pt-3 border-t border-slate-800">
              <button
                type="button"
                onClick={() => {
                  setCustomUrlInput(DEFAULT_XMLTV_URL);
                  setActiveEpgUrl(DEFAULT_XMLTV_URL);
                  setShowUrlModal(false);
                }}
                className="px-3.5 py-2 rounded-xl text-xs text-slate-400 hover:text-white"
              >
                Reset Default
              </button>
              <button
                type="button"
                onClick={() => {
                  if (customUrlInput.trim()) {
                    setActiveEpgUrl(customUrlInput.trim());
                  }
                  setShowUrlModal(false);
                }}
                className="px-4 py-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-slate-950 text-xs font-bold transition-colors shadow-md"
              >
                Apply & Reload EPG
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
